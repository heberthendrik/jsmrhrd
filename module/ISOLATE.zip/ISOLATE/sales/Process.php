<?php

include('../../library/function_list.php');


if( $_POST['module'] == "SalesAdd" ){

	$input_parameter['AGENT_ID'] = $_POST['HiddenAgentID'];
	$input_parameter['DISTRIBUTION_METHOD'] = $_POST['HiddenDistributionMethod'];
	$input_parameter['EMAIL'] = $_POST['textEmail'];
	$input_parameter['SMS'] = $_POST['textTelp'];
	
	$function_AddSales = AddTransaction($input_parameter);
	$sales_new_id = $function_AddSales['NEW_ID'];
	$send_wifiid_username = $function_AddSales['USERNAME'];
	$send_wifiid_password = $function_AddSales['PASSWORD'];
	
	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_AddSales['RESULT'];
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_AddSales['MESSAGE'];
	
	//$input_agent_parameter['ID'] = $input_parameter['AGENT_ID'];
	//$function_GetAgentByID = GetAgentByID($input_agent_parameter);
	if( $input_parameter['DISTRIBUTION_METHOD'] == 1 ){

		$time = strtotime(date('Y-m-d'));
		$input_parameter['RECIPIENT_EMAIL'] = $input_parameter['EMAIL'];
		$input_parameter['RECIPIENT_NAME'] = 'Pelanggan';
		$input_parameter['SUBJECT'] = '[NO REPLY] VOUCHER WIFI ID';
		$input_parameter['CONTENT'] = 
		'
		<p>Kepada Yth Pelanggan,</p>
		<p>Berikut ini adalah info login wifi id Anda:</p>
		<p>
		Username: '.$send_wifiid_username.'<br/>
		Password: '.$send_wifiid_password.'<br/>
		Berlaku sampai: '.date("Y-m-d", strtotime("+1 month", $time)).'
		</p>
		<p>Terima kasih</p>
		';
		
		SendSystemEmail($input_parameter);	
		header('Location:Result.php?id='.$sales_new_id);
	} else if( $input_parameter['DISTRIBUTION_METHOD'] == 2 ){
		header('Location:Result.php?id='.$sales_new_id);
		//KIRIM SMS
		
		$api_cakra = 'http://sms.cakraflash.com:8000/api/sendsms?user=ptjpu&password=KHR4yjFj&senderid=PT%20JPU&message=wifiid+username:+'.$send_wifiid_username.'+Password:+'.$send_wifiid_password.'&msisdn='.$input_parameter['SMS'];
		
		// create a new cURL resource
		$ch = curl_init();
		
		// set URL and other appropriate options
		curl_setopt($ch, CURLOPT_URL, $api_cakra);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		
		// grab URL and pass it to the browser
		curl_exec($ch);
		
		// close cURL resource, and free up system resources
		curl_close($ch);
		
		
		
		//KIRIM EMAIL
		if( strlen($input_parameter['EMAIL']) > 0 ){
			
			$time = strtotime(date('Y-m-d'));
			$input_parameter['RECIPIENT_EMAIL'] = $input_parameter['EMAIL'];
			$input_parameter['RECIPIENT_NAME'] = 'Pelanggan';
			$input_parameter['SUBJECT'] = '[NO REPLY] VOUCHER WIFI ID';
			$input_parameter['CONTENT'] = 
			'
			<p>Kepada Yth Pelanggan,</p>
			<p>Berikut ini adalah info login wifi id Anda:</p>
			<p>
			Username: '.$send_wifiid_username.'<br/>
			Password: '.$send_wifiid_password.'<br/>
			Berlaku sampai: '.date("Y-m-d", strtotime("+1 month", $time)).'
			</p>
			<p>Terima kasih</p>
			';
			
			SendSystemEmail($input_parameter);	
				
		}
		
	}
	
	
	exit;
}

else if( $_POST['module'] == "VerifikasiTransaksi" ){
	
	$input_parameter['ID'] = $_POST['HiddenCurrentID'];
	$input_parameter['IS_VERIFIED'] = $_POST['selectIsVerified'];
	$input_parameter['WIFIID_USERNAME'] = $_POST['textWifiidUsername'];
	$input_parameter['WIFIID_PASSWORD'] = $_POST['textWifiidPassword'];
	$function_VerifyTransaction = VerifyTransaction($input_parameter);
	
	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_VerifyTransaction['RESULT'];
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_VerifyTransaction['MESSAGE'];
	
	if( $input_parameter['IS_VERIFIED'] == 1 ){
		$function_GetTransactionByID = GetTransactionByID($input_parameter);
		$agent_id = $function_GetTransactionByID['AGENT_ID'][0];
		
		$input_agent_parameter['ID'] = $agent_id;
		$function_GetAgentByID = GetAgentByID($input_agent_parameter);
		$input_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
		$input_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
		$input_parameter['SUBJECT'] = '[NO REPLY] USERNAME DAN PASSWORD TELAH TERKIRIM';
		$input_parameter['CONTENT'] = 
		'
		<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
		<p>Username dan password untuk transaksi dengan ID transaksi #'.$input_parameter['ID'].' telah berhasil terkirim ke pelanggan.</p>
		<p>Terima kasih</p>
		';
		
		SendSystemEmail($input_parameter);	
		
		
		
		//SEND INFO TO CUSTOMER
		if( $function_GetTransactionByID['DISTRIBUTION_METHOD'][0] == 1 ){
			
			$input_parameter['RECIPIENT_EMAIL'] = $function_GetTransactionByID['EMAIL'][0];
			$input_parameter['RECIPIENT_NAME'] = 'Pelanggan';
			$input_parameter['SUBJECT'] = '[NO REPLY] USERNAME DAN PASSWORD WIFI ID ANDA';
			$input_parameter['CONTENT'] = 
			'
			<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
			<p>Transaksi (ID Transaksi #'.$input_parameter['ID'].') telah berhasil. Berikut ini adalah username dan password yang dapat Anda gunakan .</p>
			<p>
			Username: <strong>'.$function_GetTransactionByID['WIFIID_USERNAME'][0].'</strong><br/>
			Password: <strong>'.$function_GetTransactionByID['WIFIID_PASSWORD'][0].'</strong>
			</p>
			<p>Terima kasih</p>
			';
			
			SendSystemEmail($input_parameter);	
			
		}
	}
	
	header('Location:Detail.php?id='.$input_parameter['ID']);
	exit;
}

?>