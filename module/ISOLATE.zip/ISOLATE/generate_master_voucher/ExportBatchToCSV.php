<?php

include('../../library/function_list.php');

$input_parameter['BATCH_ID'] = $_GET['bid'];
$function_GetMasterVoucherByBatchID = GetMasterVoucherByBatchID($input_parameter);

?>
<table>
<?php

for( $i=0;$i<$function_GetMasterVoucherByBatchID['TOTAL_ROW'];$i++ ){
	
	echo '<tr>';
	echo '<td>'.$function_GetMasterVoucherByBatchID['USERNAME'][$i].'</td>';
	echo '<Td>'.$function_GetMasterVoucherByBatchID['PASSWORD'][$i].'</td>';
	echo '</tr>';
	
}

?>
</table>