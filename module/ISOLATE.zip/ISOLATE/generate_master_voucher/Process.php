<?php

include('../../library/function_list.php');


if( $_POST['module'] == "GenerateVoucher" ){

	$input_parameter['TOTAL_VOUCHER'] = $_POST['textJumlahVoucher'];
	$input_parameter['KODE_UNIK_USERNAME'] = $_POST['textKodeUnikUsername'];
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = GenerateMassVoucher($input_parameter);
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		if( $function_result['RESULT'] == 0 ){
			
			header("Location:Add.php");
			exit;
			
		} else if( $function_result['RESULT'] == 1 ){
			
			header("Location:View.php");
			exit;
			
		} else {
			header("Location:View.php");
			exit;
		}
		
	}
	
}

if( $_POST['module'] == "BrandDetail" ){
	
	$input_parameter['ID'] = $_POST['HiddenCurrentID'];
	$input_parameter['BRAND'] = $_POST['textBrand'];
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = UpdateBrandByID($input_parameter);
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		if( $function_result['RESULT'] == 0 ){
			
			header("Location:Detail.php?id=".$input_parameter['ID']);
			exit;
			
		} else if( $function_result['RESULT'] == 1 ){
			
			header("Location:Detail.php?id=".$input_parameter['ID']);
			exit;
			
		} else {
			header("Location:View.php");
			exit;
		}
	} 
}

if( $_GET['action'] == 'ActivationBatch' ){
	
	$input_parameter['BATCH_ID'] = $_GET['bid'];
	$function_ActivateBatch = ActivateBatch($input_parameter);
	
	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_ActivateBatch['RESULT'];
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_ActivateBatch['MESSAGE'];
	
	header("Location:View.php");
	exit;
	
}
?>