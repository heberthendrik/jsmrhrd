<?php include('../include/top_header.php') ?>

			<div class="inner">
				<!--\\\\\\\ inner start \\\\\\-->
				
				<?php include('../include/navigation_sidebar.php'); ?>	
				
				<!-- TOOLBAR TEXTEDITOR -->
				<style>
				.wysihtml5-toolbar > li{
					display:none!important;
				}
				.compose-mail{
					margin-top:0px;
				}
				.compose-editor{
					margin-top:0px!important;
				}
				</style>
				
				<div class="contentpanel">
					<!--\\\\\\\ contentpanel start\\\\\\-->
					<div class="pull-left breadcrumb_admin clear_both">
						<div class="pull-left page_title theme_color">
							<h1>Broadcast</h1>
						</div>
					</div>
					<div class="container clear_both padding_fix">
						<!--\\\\\\\ container  start \\\\\\-->
						<div class="row">
							<div class="col-sm-12 col-lg-12">
								<div class="block-web">
									<form method="post" role="form-horizontal" action="Process.php">
									
										<div class="form-group">
											<input type="text" class="form-control" id="subject" tabindex="1" name="textJudulPesan" placeholder="Ketik Judul Pesan ..." style="border:1px solid #a9a9a9 !important;">
										</div>
										<div class="compose-mail">
											<div class="compose-editor" style="margin-top:10px;">
												<textarea id="text-editor" class="compose-editor2" placeholder="Tulis Pesan ..." class="col-xs-12" rows="25" name="textPesan"></textarea>
											</div>
										</div>
										<div class="bottom">
											<input type="hidden" name="module" value="SendMessage" />
											<input type="submit" value="Kirim" class="btn btn-primary">
										</div>
									</form>
								</div>
								<!--/ block-web --> 
							</div>
							<!-- /col-sm-9 --> 
						</div>
						<!--/row--> 
					</div>
					<!--\\\\\\\ container  end \\\\\\-->
				</div>
				<!--\\\\\\\ content panel end \\\\\\-->
			</div>
			<!--\\\\\\\ inner end\\\\\\-->
		</div>
		<!--\\\\\\\ wrapper end\\\\\\-->
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Compose New Task</h4>
					</div>
					<div class="modal-body"> content </div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary">Save changes</button>
					</div>
				</div>
			</div>
		</div>
		<!-- sidebar chats -->
		<nav class="atm-spmenu atm-spmenu-vertical atm-spmenu-right side-chat">
			<div class="header">
				<input type="text" class="form-control chat-search" placeholder=" Search">
			</div>
			<div href="#" class="sub-header">
				<div class="icon"><i class="fa fa-user"></i></div>
				<p>Online (4)</p>
			</div>
			<div class="content">
				<p class="title">Family</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Steven Smith</a></li>
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> John Doe</a></li>
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Michael Smith</a></li>
					<li class="busy"><a href="#"><i class="fa fa-circle-o"></i> Chris Rogers</a></li>
				</ul>
				<p class="title">Friends</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Vernon Philander</a></li>
					<li class="outside"><a href="#"><i class="fa fa-circle-o"></i> Kyle Abbott</a></li>
					<li><a href="#"><i class="fa fa-circle-o"></i> Dean Elgar</a></li>
				</ul>
				<p class="title">Work</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li><a href="#"><i class="fa fa-circle-o"></i> Dale Steyn</a></li>
					<li><a href="#"><i class="fa fa-circle-o"></i> Morne Morkel</a></li>
				</ul>
			</div>
			<div id="chat-box">
				<div class="header">
					<span>Richard Avedon</span>
					<a class="close"><i class="fa fa-times"></i></a>    
				</div>
				<div class="messages nano nscroller has-scrollbar">
					<div class="content" tabindex="0" style="right: -17px;">
						<ul class="conversation">
							<li class="odd">
								<p>Hi John, how are you?</p>
							</li>
							<li class="text-right">
								<p>Hello I am also fine</p>
							</li>
							<li class="odd">
								<p>Tell me what about you?</p>
							</li>
							<li class="text-right">
								<p>Sorry, I'm late... see you</p>
							</li>
							<li class="odd unread">
								<p>OK, call me later...</p>
							</li>
						</ul>
					</div>
					<div class="pane" style="display: none;">
						<div class="slider" style="height: 20px; top: 0px;"></div>
					</div>
				</div>
				<div class="chat-input">
					<div class="input-group">
						<input type="text" placeholder="Enter a message..." class="form-control">
						<span class="input-group-btn">
						<button class="btn btn-danger" type="button">Send</button>
						</span>      
					</div>
				</div>
			</div>
		</nav>
		<!-- /sidebar chats -->   

		<script src="../../repo/js/jquery-2.1.0.js"></script>
		<script src="../../repo/js/bootstrap.min.js"></script>
		<script src="../../repo/js/common-script.js"></script>
		<script src="../../repo/js/jquery.slimscroll.min.js"></script>
		<script src="../../repo/plugins/map/jquery-jvectormap-1.2.2.min.js"></script>
		<script src="../../repo/plugins/map/jquery-jvectormap-world-mill-en.js"></script>
		<script src="../../repo/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script> 
		<script src="../../repo/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script> 
		<script>
			$(document).ready(function() {
				$('#text-editor').wysihtml5();	
				$("#quick-access").css("bottom","0px");				
			});		
		</script>
		
		<!-- AUTO COMPLETE -->
		<script>
		$(function() {
		    $( "#skills" ).autocomplete({
		        source: 'SearchAjax.php'
		    });
		});
		</script>
		
	</body>
</html>