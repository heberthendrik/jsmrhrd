<?php

include('../../library/function_list.php');


if( $_POST['module'] == "SendMessage" ){

	$input_parameter['SUBJECT'] = $_POST['textJudulPesan'];
	$input_parameter['MESSAGE'] = $_POST['textPesan'];
	
	$function_BroadcastMessage = BroadcastMessage($input_parameter);
	
	header("Location:View.php");
	exit;
	
}

?>