<?php

include('../../library/function_list.php');


if( $_POST['module'] == "AccessPointAdd" ){

	$input_parameter['AGENT_ID'] = $_POST['selectAgentID'];
	$input_parameter['BRAND_ID'] = $_POST['selectBrandID'];
	$input_parameter['SERIAL_NUMBER'] = $_POST['textSerialNumber'];
	$input_parameter['LOCATION_ID'] = $_POST['selectLocationID'];
	$input_parameter['VENUE'] = $_POST['textNamaTempat'];
	$input_parameter['ADDRESS'] = $_POST['textAddress'];
	$input_parameter['LONGITUDE'] = $_POST['textLongitude'];
	$input_parameter['LATITUDE'] = $_POST['textLatitude'];
	$input_parameter['IS_ACTIVE'] = $_POST['selectStatus'];
	$input_parameter['IS_APPROVED'] = $_POST['selectIsApproved'];
	$input_parameter['IZIN_LOKASI'] = $_FILES['fileIzinLokasiAP'];
	$input_parameter['BUKTI_JARINGAN_TELKOM'] = $_FILES['fileBuktiJaringanTelkom'];
	
	$brand_parameter['ID'] = $input_parameter['BRAND_ID'];
	$function_GetBrandByID = GetBrandByID($brand_parameter);
	
	$location_parameter['ID'] = $input_parameter['LOCATION_ID'];
	$function_GetLocationByID = GetLocationByID($location_parameter);
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = AddAccessPoint($input_parameter);
		$ap_new_id = $function_result['NEW_ID'];
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		//UPLOAD IZIN LOKASI
		mkdir('../../media_library/izin_lokasi_ap/'.$ap_new_id);
		$upload_parameter['TARGET_DIRECTORY'] = '../../media_library/izin_lokasi_ap/'.$ap_new_id;
		$upload_parameter['IMAGE_FILE'] = $input_parameter['IZIN_LOKASI'];
		CustomUploadFile($upload_parameter);
		
		//UPLOAD BUKTI JARINGAN TELKOM
		mkdir('../../media_library/bukti_jaringan_telkom/'.$ap_new_id);
		$upload_parameter['TARGET_DIRECTORY'] = '../../media_library/bukti_jaringan_telkom/'.$ap_new_id;
		$upload_parameter['IMAGE_FILE'] = $input_parameter['BUKTI_JARINGAN_TELKOM'];
		CustomUploadFile($upload_parameter);
		
		if( $input_parameter['IS_APPROVED'] == 1 && $function_result['RESULT'] == 1 ){
		
			$owner_parameter['ID'] = $input_parameter['AGENT_ID'];
			$function_GetAgentByID = GetAgentByID($owner_parameter);
		
			$email_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
			$email_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
			$email_parameter['SUBJECT'] = '[NO REPLY] JPU WIFIID -- ACCESS POINT ANDA TELAH DI VALIDASI';
			$email_parameter['CONTENT'] = 
			'
			<p>Kepada '.strtoupper($email_parameter['RECIPIENT_NAME']).',</p>
			<p>Access Point Anda dengan data berikut ini:</p>
			<p>
			Merk: '.$function_GetBrandByID['BRAND'][0].'<br/>
			Nomor Seri: '.$input_parameter['SERIAL_NUMBER'].'<br/>
			Lokasi: '.$function_GetLocationByID['LOCATION'][0].'<br/>
			Nama Tempat: '.$input_parameter['VENUE'].'<br/>
			Alamat: '.$input_parameter['ADDRESS'].'<br/>
			Longitude: '.$input_parameter['LONGITUDE'].'<br/>
			Latitude: '.$input_parameter['LATITUDE'].'<br/>
			</p>
			<p>telah kami setujui.</p> 
			<p>
			Pengiriman dan pemasangan access point akan membutuhkan waktu 2 minggu - 1 bulan mengikuti layanan telkom indonesia.
			<br/>Call center 1500250
			</p>
			<p>Terima kasih</p>
			';
			
			SendSystemEmail($email_parameter);
		}
		
		if( $function_result['RESULT'] == 0 ){
			
			header("Location:Add_1_.php");
			exit;
			
		} else if( $function_result['RESULT'] == 1 ){
			
			header("Location:Detail.php?id=".$ap_new_id);
			exit;
			
		} else {
			header("Location:View.php");
			exit;
		}
		
	}
	
}

if( $_POST['module'] == "AccessPointDetail" ){
	
	$input_parameter['ID'] = $_POST['HiddenCurrentID'];
	$input_parameter['AGENT_ID'] = $_POST['selectAgentID'];
	$input_parameter['BRAND_ID'] = $_POST['selectBrandID'];
	$input_parameter['SERIAL_NUMBER'] = $_POST['textSerialNumber'];
	$input_parameter['LOCATION_ID'] = $_POST['selectLocationID'];
	$input_parameter['VENUE'] = $_POST['textNamaTempat'];
	$input_parameter['ADDRESS'] = $_POST['textAddress'];
	$input_parameter['LONGITUDE'] = $_POST['textLongitude'];
	$input_parameter['LATITUDE'] = $_POST['textLatitude'];
	$input_parameter['IS_ACTIVE'] = $_POST['selectStatus'];
	$input_parameter['IS_APPROVED'] = $_POST['selectIsApproved'];
	$input_parameter['IZIN_LOKASI'] = $_FILES['fileIzinLokasiAP'];
	$input_parameter['BUKTI_JARINGAN_TELKOM'] = $_FILES['fileBuktiJaringanTelkom'];
	
	$brand_parameter['ID'] = $input_parameter['BRAND_ID'];
	$function_GetBrandByID = GetBrandByID($brand_parameter);
	
	$location_parameter['ID'] = $input_parameter['LOCATION_ID'];
	$function_GetLocationByID = GetLocationByID($location_parameter);
	
	$current_ap_parameter['ID'] = $input_parameter['ID'];
	$function_GetAccessPointByID = GetAccessPointByID($current_ap_parameter);
	$current_status_approval = $function_GetAccessPointByID['IS_APPROVED'][0];
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = UpdateAccessPointByID($input_parameter);
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		if( $current_status_approval == 0 && $input_parameter['IS_APPROVED'] == 1 && $function_result['RESULT'] == 1 ){
		
			//USE AP CREDIT
			$useapcredit_parameter['AGENT_ID'] = $input_parameter['AGENT_ID'];
			$function_UseAPCredit = UseAPCredit($useapcredit_parameter);
		
			//KIRIM EMAIL NOTIFIKASI VALIDASI ACCESS POINT
			$owner_parameter['ID'] = $input_parameter['AGENT_ID'];
			$function_GetAgentByID = GetAgentByID($owner_parameter);
		
			$email_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
			$email_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
			$email_parameter['SUBJECT'] = '[NO REPLY] JPU WIFIID -- ACCESS POINT ANDA TELAH DI VALIDASI';
			$email_parameter['CONTENT'] = 
			'
			<p>Kepada '.strtoupper($email_parameter['RECIPIENT_NAME']).',</p>
			<p>Access Point Anda dengan data berikut ini:</p>
			<p>
			Merk: '.$function_GetBrandByID['BRAND'][0].'<br/>
			Nomor Seri: '.$input_parameter['SERIAL_NUMBER'].'<br/>
			Lokasi: '.$function_GetLocationByID['LOCATION'][0].'<br/>
			Nama Tempat: '.$input_parameter['VENUE'].'<br/>
			Alamat: '.$input_parameter['ADDRESS'].'<br/>
			Longitude: '.$input_parameter['LONGITUDE'].'<br/>
			Latitude: '.$input_parameter['LATITUDE'].'<br/>
			</p>
			<p>telah kami setujui.</p> 
			<p>
			Pengiriman dan pemasangan access point akan membutuhkan waktu 2 minggu - 1 bulan mengikuti layanan telkom indonesia.
			<br/>Call center 1500250
			</p>
			<p>Terima kasih</p>
			';
			
			SendSystemEmail($email_parameter);
		}
		
		if( strlen($input_parameter['IZIN_LOKASI']['name']) > 0 ){
			echo 'upload izin lokasi: '.$input_parameter['IZIN_LOKASI']['name'];
		}
		
		if( strlen($input_parameter['BUKTI_JARINGAN_TELKOM']['name']) > 0 ){
			echo 'upload bukti jaringan telkom: '.$input_parameter['BUKTI_JARINGAN_TELKOM']['name'];
		}
		
		exit;
		
		
		if( $function_result['RESULT'] == 0 ){
			
			header("Location:Detail.php?id=".$input_parameter['ID']);
			exit;
			
		} else if( $function_result['RESULT'] == 1 ){
			
			header("Location:Detail.php?id=".$input_parameter['ID']);
			exit;
			
		} else {
			header("Location:View.php");
			exit;
		}
	} 
}

else if( $_GET['action'] == 'DeleteAP' ){

	$ap_id = $_GET['apid'];
	
	$delete_parameter['ID'] = $ap_id;
	
	$function_DeleteAccessPointByID = DeleteAccessPointByID($delete_parameter);
	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_DeleteAccessPointByID['RESULT'];
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_DeleteAccessPointByID['MESSAGE'];
	
	header("Location:View.php");
	exit;
}

?>