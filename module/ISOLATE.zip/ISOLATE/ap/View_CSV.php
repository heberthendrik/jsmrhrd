<?php include('../../library/function_list.php') ?>
			<style>
				table, th, td {
				   border: 1px solid black;
				}
				table{
					border-collapse: collapse;
				}
			</style>
			
													<table>
														<thead>
															<tr>
																<th>ID</th>
																<th>Nama Agen</th>
																<th>Merk</th>
																<th>Serial Number</th>
																<th>Nama Tempat</th>
																<th>Lokasi</th>
																<th>Alamat</th>
																<th>Longitude</th>
																<th>Latitude</th>
																<th>Izin Lokasi</th>
																<th>Bukti Jaringan Telkom</th>
																<th>Status Aktif</th>
																<th>Status Approval</th>
																<th>Tanggal Pendaftaran</th>
															</tr>
														</thead>
														<tbody>
															<?php
															
															$function_GetAllAccessPoint = GetAllAccessPoint();
															
															for( $i=0;$i<$function_GetAllAccessPoint['TOTAL_ROW'];$i++ ){
															
																$agent_parameter['ID'] = $function_GetAllAccessPoint['AGENT_ID'][$i];
																$function_GetAgentByID = GetAgentByID($agent_parameter);
																
																$location_parameter['ID'] = $function_GetAllAccessPoint['LOCATION_ID'][$i];
																$function_GetLocationByID = GetLocationByID($location_parameter);
															
																if( $function_GetAllAccessPoint['IS_ACTIVE'][$i] == 1 ){
																	$display_active = '<span style="color:green;">Aktif</span>';
																} else if( $function_GetAllAccessPoint['IS_ACTIVE'][$i] == 0 ){
																	$display_active = '<span style="color:red;">Tidak Aktif</span>';
																}
																
																if( $function_GetAllAccessPoint['IS_APPROVED'][$i] == 1 ){
																	$display_approval = '<span style="color:green;">Disetujui</span>';
																} else if( $function_GetAllAccessPoint['IS_APPROVED'][$i] == 0 ){
																	$display_approval = '<span style="color:red;">Belum Disetujui</span>';
																}
																
																if( strlen($function_GetAllAccessPoint['IZIN_LOKASI'][$i]) > 0 ){
																	$display_izinlokasi = '<span style="color:green;">Ada</span>';
																} else if( strlen($function_GetAllAccessPoint['IZIN_LOKASI'][$i]) == 0 ){
																	$display_izinlokasi = '<span style="color:red;">Belum Ada</span>';
																}
																
																if( strlen($function_GetAllAccessPoint['BUKTI_JARINGAN_TELKOM'][$i]) > 0 ){
																	$display_buktijaringantelkom = '<span style="color:green;">Ada</span>';
																} else if( strlen($function_GetAllAccessPoint['BUKTI_JARINGAN_TELKOM'][$i]) == 0 ){
																	$display_buktijaringantelkom = '<span style="color:red;">Belum Ada</span>';
																}
																
																$brand_parameter['ID'] = $function_GetAllAccessPoint['BRAND_ID'][$i];
																$function_GetBrandByID = GetBrandByID($brand_parameter);
															
																?>
																<tr>
																	<td><?php echo $function_GetAllAccessPoint['ID'][$i];?></td>
																	<td><?php echo $function_GetAgentByID['FULL_NAME'][0];?></td>
																	<td><?php echo $function_GetBrandByID['BRAND'][0];?></td>
																	<td><?php echo $function_GetAllAccessPoint['SERIAL_NUMBER'][$i];?></td>
																	<td><?php echo $function_GetAllAccessPoint['VENUE'][$i];?></td>
																	<td><?php echo $function_GetLocationByID['LOCATION'][0];?></td>
																	<td><?php echo $function_GetAllAccessPoint['ADDRESS'][$i];?></td>
																	<td><?php echo $function_GetAllAccessPoint['LONGITUDE'][$i];?></td>
																	<td><?php echo $function_GetAllAccessPoint['LATITUDE'][$i];?></td>
																	<td><?php echo $display_izinlokasi;?></td>
																	<td><?php echo $display_buktijaringantelkom;?></td>
																	<td><?php echo $display_active;?></td>
																	<td><?php echo $display_approval;?></td>
																	<td><?php echo $function_GetAllAccessPoint['DATE_CREATED'][$i];?></td>
																</tr>
																<?php
															}
															?>
														</tbody>
													</table>