<?php include('../../library/function_list.php') ;?>
			<style>
				table, th, td {
				   border: 1px solid black;
				}
				table{
					border-collapse: collapse;
				}
			</style>
			
													<table>
														<thead>
															<tr>
																<th>ID</th>
																<th>Kode Agen</th>
																<th>Nama</th>
																<th>Email</th>
																<th>Bank</th>
																<th>No Rek</th>
																<th>NPWP</th>
																<th>No Telp</th>
																<th>No KTP / SIM</th>
																<th>Referal</th>
																<th>Status Aktif</th>
																<th>Status Verifikasi</th>
																<th>Tanggal Terdaftar</th>
															</tr>
														</thead>
														<tbody>
															<?php
															
															$function_GetAllAgent = GetAllAgent();
															
															for( $i=0;$i<$function_GetAllAgent['TOTAL_ROW'];$i++ ){
															
																if( $function_GetAllAgent['IS_ACTIVE'][$i] == 1 ){
																	$display_active = '<span style="color:green;">Aktif</span>';
																} else {
																	$display_active = '<span style="color:red;">Non Aktif</span>';
																}
																
																if( $function_GetAllAgent['IS_VERIFIED'][$i] == 1 ){
																	$display_verified = '<span style="color:green;">Sudah</span>';
																} else {
																	$display_verified = '<span style="color:red;">Belum</span>';
																}
																
																if( $function_GetAllAgent['ID'][$i] != 769 ){
																
																	$bank_parameter['ID'] = $function_GetAllAgent['BANK_ID'][$i];
																	$function_GetBankByID = GetBankByID($bank_parameter);
																	
																	$referal_parameter['ID'] = $function_GetAllAgent['REFERAL_ID'][$i];
																	$function_GetAgentByID = GetAgentByID($referal_parameter);
																
																	?>
																	<tr>
																		<td><?php echo $function_GetAllAgent['ID'][$i];?></td>
																		<td><?php echo $function_GetAllAgent['AGENT_CODE'][$i];?></td>
																		<td><?php echo $function_GetAllAgent['FULL_NAME'][$i];?></td>
																		<td><?php echo $function_GetAllAgent['EMAIL'][$i];?></td>
																		<td><?php echo $function_GetBankByID['BANK'][0];?></td>
																		<td><?php echo $function_GetAllAgent['BANK_ACCOUNT_NO'][$i];?></td>
																		<td><?php echo $function_GetAllAgent['NPWP'][$i];?></td>
																		<td><?php echo $function_GetAllAgent['NO_TELP'][$i];?></td>
																		<td><?php echo $function_GetAllAgent['NO_KTP_SIM'][$i];?></td>
																		<td><?php echo $function_GetAgentByID['FULL_NAME'][0];?></td>
																		<td><?php echo $display_active;?></td>
																		<td><?php echo $display_verified;?></td>
																		<td><?php echo $function_GetAllAgent['DATE_CREATED'][$i];?></td>
																	</tr>
																	<?php	
																}
															
															}
															?>
														</tbody>
													</table>