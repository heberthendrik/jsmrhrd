<?php

include('../../library/function_list.php');

if( $_POST['module'] == "AgentAdd_1_" ){
	
	$input_parameter['AGENT_CODE'] = $_POST['textKodeReferal'];
	$function_GetAgentByAgentCode = GetAgentByAgentCode($input_parameter);
	
	if( $function_GetAgentByAgentCode > 0 ){
		
		header('Location:Add_2_.php?ra='.$function_GetAgentByAgentCode);
		exit;
		
	} else {
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = 0;
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = 'Data referal tidak terdaftar';
		header('Location:Add_1_.php');
		exit;
	}
	
}


if( $_POST['module'] == "AgentAdd_2_" ){

	$input_parameter['FULL_NAME'] = $_POST['textNama'];
	$input_parameter['EMAIL'] = $_POST['textEmail'];
	$input_parameter['BANK_ID'] = $_POST['selectBankID'];
	$input_parameter['BANK_ACCOUNT_NO'] = $_POST['textNomorRekening'];
	$input_parameter['NPWP'] = $_POST['textNPWP'];
	$input_parameter['NO_TELP'] = $_POST['textNoTelp'];
	$input_parameter['NO_KTP_SIM'] = $_POST['textNoKTPSIM'];
	$input_parameter['REFERAL_ID'] = $_POST['selectReferalID'];
	$input_parameter['COMISSION'] = $_POST['textKomisi'];
	$input_parameter['DATE_EFFECTIVE'] = date('Y-m-d');
	$input_parameter['IS_ACTIVE'] = $_POST['selectStatus'];
	$input_parameter['AGENT_CODE_PARAMETER'] = $_POST['selectAgentCode'];
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = AddAgent($input_parameter);
		$agent_new_id = $function_result['NEW_ID'];
		
		$input_parameter['ID'] = $agent_new_id;
		$input_parameter['DATE_EFFECTIVE'] = date('Y-m-d');
		AddComissionHistory($input_parameter);
		
		$input_parameter['AGENT_ID'] = $agent_new_id;
		UpdateLatestComission($input_parameter);
		
		AssignAgentCode($input_parameter);
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		if( $function_result['RESULT'] == 0 ){
			
			header("Location:Add_2_.php");
			exit;
			
		} else if( $function_result['RESULT'] == 1 ){
			
			header("Location:Detail.php?id=".$agent_new_id);
			exit;
			
		} else {
			header("Location:View.php");
			exit;
		}
		
	}
	
}

if( $_POST['module'] == "AgentDetail" ){
	
	$input_parameter['ID'] = $_POST['HiddenCurrentID'];
	$input_parameter['FULL_NAME'] = $_POST['textNama'];
	$input_parameter['EMAIL'] = $_POST['textEmail'];
	$input_parameter['BANK_ID'] = $_POST['selectBankID'];
	$input_parameter['BANK_ACCOUNT_NO'] = $_POST['textNomorRekening'];
	$input_parameter['NPWP'] = $_POST['textNPWP'];
	$input_parameter['NO_TELP'] = $_POST['textNoTelp'];
	$input_parameter['NO_KTP_SIM'] = $_POST['textNoKTPSIM'];
	$input_parameter['REFERAL_ID'] = $_POST['selectReferalID'];
	$input_parameter['IS_ACTIVE'] = $_POST['selectStatus'];
	$input_parameter['IS_VERIFIED'] = $_POST['HiddenIsVerified'];
	
	if( $_POST['optional'] == 'ForceChangeReferalID' ){
		$input_parameter['REFERAL_ID'] = $_POST['selectReferalID'];
	} else {
		$parameter_for_referal['ID'] = $input_parameter['ID'];
		$function_GetAgentByID = GetAgentByID($parameter_for_referal);
		$input_parameter['REFERAL_ID'] = $function_GetAgentByID['REFERAL_ID'][0];
	}
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = UpdateAgentByID($input_parameter);
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		if( $function_result['RESULT'] == 0 ){
			
			header("Location:Detail.php?id=".$input_parameter['ID']);
			exit;
			
		} else if( $function_result['RESULT'] == 1 ){
			
			header("Location:Detail.php?id=".$input_parameter['ID']);
			exit;
			
		} else {
			header("Location:View.php");
			exit;
		}
	} else if( isset( $_POST['submitVerifySMS'] ) ){
	
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = 1;
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = "SMS berisi link verifikasi telah berhasil terkirim";
		header("Location:Detail.php?id=".$input_parameter['ID']);
		exit;	
	
	}
}

if( $_GET['action'] == "verifyemail" ){

	$id = $_GET['id'];
	$input_getuser_parameter['ID'] = $id;
	$function_GetAgentByID = GetAgentByID($input_getuser_parameter);
	$master_link = GetMasterLink();
	

	$input_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
	$input_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
	$input_parameter['SUBJECT'] = '[NO REPLY] JPU WIFIID -- KONFIRMASI PENDAFTARAN AGEN';
	$input_parameter['CONTENT'] = 
	'
	<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
	<p>Email ini telah didaftarkan sebagai agen wifiid. Silahkan klik link dibawah untuk melakukan konfirmasi email ini.</p>
	<p>'.$master_link.'module/agent_email_verification/Process.php?action=x&id='.$id.'&email='.$input_parameter['RECIPIENT_EMAIL'].'</p>
	<p>Terima kasih</p>
	';
	
	SendSystemEmail($input_parameter);

	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = 1;
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = "Email berisi link verifikasi telah berhasil terkirim";	
	
	header("Location:Detail.php?id=".$id);
	exit;
}


if( $_POST['module'] == "ComissionUpdate" ){
	
	$input_parameter['ID'] = $_POST['HiddenCurrentID'];
	$input_parameter['COMISSION'] = $_POST['textKomisi'];
	$input_parameter['DATE_EFFECTIVE'] = ConvertDateFormToDB($_POST['dateTanggalEfektifKomisi']);
	
	AddComissionHistory($input_parameter);
	
	$current_agent_id = $input_parameter['ID'];
	$input_parameter_referalsellprice['ID'] = $current_agent_id;
	$referal_sell_price_value = GetReferalSellPriceByAgentID($input_parameter_referalsellprice);
	
	
	
	
	header("Location:Detail.php?id=".$input_parameter['ID']);
	exit;
	
}

?>