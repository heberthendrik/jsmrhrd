<?php

include('../../library/function_list.php');


if( $_POST['module'] == "LocationAdd" ){

	$input_parameter['LOCATION'] = $_POST['textLocation'];
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = AddLocation($input_parameter);
		$location_new_id = $function_result['NEW_ID'];
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		if( $function_result['RESULT'] == 0 ){
			
			header("Location:Add.php");
			exit;
			
		} else if( $function_result['RESULT'] == 1 ){
			
			header("Location:Detail.php?id=".$location_new_id);
			exit;
			
		} else {
			header("Location:View.php");
			exit;
		}
		
	}
	
}

if( $_POST['module'] == "LocationDetail" ){
	
	$input_parameter['ID'] = $_POST['HiddenCurrentID'];
	$input_parameter['LOCATION'] = $_POST['textLocation'];
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = UpdateLocationByID($input_parameter);
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		if( $function_result['RESULT'] == 0 ){
			
			header("Location:Detail.php?id=".$input_parameter['ID']);
			exit;
			
		} else if( $function_result['RESULT'] == 1 ){
			
			header("Location:Detail.php?id=".$input_parameter['ID']);
			exit;
			
		} else {
			header("Location:View.php");
			exit;
		}
	} 
}

?>