<?php

include('../../library/function_list.php');


if( $_POST['module'] == "HargaUtamaDetail" ){

	$input_parameter['PARAMETER'] = 'MASTER_SELL_PRICE';
	$input_parameter['VALUE'] = $_POST['textHarga'];
	
	if( isset( $_POST['submitSimpan'] ) ){
		
		$function_result = UpdateMasterSetting($input_parameter);
		
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_result['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_result['MESSAGE'];
		
		$id_master_jpu = 769;
		$input_parameter_sellpricehistory['DATE_EFFECTIVE'] = date('Y-m-d');
		$input_parameter_sellpricehistory['ID'] = $id_master_jpu;
		$input_parameter_sellpricehistory['SELL_PRICE'] = $input_parameter['VALUE'];
		$function_AddSellPriceHistory = AddSellPriceHistory($input_parameter_sellpricehistory);
		
		$input_parameter_updatesellprice['AGENT_ID'] = $id_master_jpu;
		$function_UpdateLatestSellPrice = UpdateLatestSellPrice($input_parameter_updatesellprice);
		
		header("Location:HargaUtama.php");
		exit;
		
	}
	
}

?>