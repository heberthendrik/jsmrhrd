<?php
include('../../library/function_list.php');
?>
<style>
table, tr, td{
	border:1px solid #333;
	border-collapse: collapse;
	padding:5px;
}
</style>
<?php
$query = "select * from agen where 1 ";

if( $_POST['BANK_ID'] != 'All' ){
	
	$query .= " and BANK_ID ".$_POST['BANK_ARGUMENT']." '".$_POST['BANK_ID']."' ";
	
}

if( strlen($_POST['AP_CREDIT']) > 0 ){
	
	$query .= " and AP_CREDIT ".$_POST['AP_CREDIT_ARGUMENT']." '".$_POST['AP_CREDIT']."' ";
	
}

if( $_POST['IS_ACTIVE'] != 'All' ){
	
	$query .= " and IS_ACTIVE ".$_POST['IS_ACTIVE_ARGUMENT']." '".$_POST['IS_ACTIVE']."' ";
	
}

if( $_POST['IS_VERIFIED'] != 'All' ){
	
	$query .= " and IS_VERIFIED ".$_POST['IS_VERIFIED_ARGUMENT']." '".$_POST['IS_VERIFIED']."' ";
	
}

if( strlen($_POST['DATE_CREATED']) > 0 ){
	
	$query .= " and DATE_FORMAT(DATE_CREATED, '%Y %m %d') ".$_POST['DATE_CREATED_ARGUMENT']." DATE_FORMAT('".$_POST['DATE_CREATED']."', '%Y %m %d') ";
	
}

$query .= " order by FULL_NAME ASC ";

/* echo $query; */
$result = $db->query($query);
$num = $result->num_rows;

if( $num > 0 ){
	$num = $num;
} else {
	$num = 0;
}

echo '<p>'.$num.' data ditemukan</p>';

for( $i=0;$i<$num;$i++ ){
	$row = $result->fetch_assoc();
	$array_id = $row['ID'];
	$array_agentcode = stripslashes($row['AGENT_CODE']);
	$array_fullname = stripslashes($row['FULL_NAME']);
	$array_email = stripslashes($row['EMAIL']);
	$array_bankid = stripslashes($row['BANK_ID']);
	$array_bankaccountno = stripslashes($row['BANK_ACCOUNT_NO']);
	$array_npwp = stripslashes($row['NPWP']);
	$array_notelp = stripslashes($row['NO_TELP']);
	$array_noktpsim = stripslashes($row['NO_KTP_SIM']);
	$array_referalid = stripslashes($row['REFERAL_ID']);
	$array_apcredit = stripslashes($row['AP_CREDIT']);
	$array_isactive = stripslashes($row['IS_ACTIVE']);
	$array_isverified = stripslashes($row['IS_VERIFIED']);
	$array_date_created = $row['DATE_CREATED'];
	$array_date_modified = $row['DATE_MODIFIED'];
	
	$bank_parameter['ID'] = $array_bankid;
	$function_GetBankByID = GetBankByID($bank_parameter);
	$display_bank = $function_GetBankByID['BANK'][0];
	
	if( $array_isactive == 0 ){
		$display_active = '<span style="color:red">Belum aktif</span>';
	} else if( $array_isactive == 1 ){
		$display_active = '<span style="color:green">Sudah aktif</span>';
	} 
	
	if( $array_isverified == 0 ){
		$display_verified = '<span style="color:red">Belum Verifikasi Email</span>';
	} else if( $array_isverified == 1 ){
		$display_verified = '<span style="color:green">Sudah Verifikasi Email</span>';
	} 
	
	$table_content .=
	'
	<tr>
		<td>'.$array_id.'</td>
		<td>'.$array_agentcode.'</td>
		<td>'.$array_fullname.'</td>
		<td>'.$array_email.'</td>
		<td>'.$display_bank.'</td>
		<td>'.$array_bankaccountno.'</td>
		<td>'.$array_npwp.'</td>
		<td>'.$array_notelp.'</td>
		<td>'.$array_noktpsim.'</td>
		<td>'.$array_referalid.'</td>
		<td>'.$array_apcredit.'</td>
		<td>'.$display_active.'</td>
		<td>'.$display_verified.'</td>
		<td>'.$array_date_created.'</td>
	</tr>
	';
}

echo '
<table>
	<tr>
		<td>ID</td>
		<td>KODE AGEN</td>
		<td>NAMA</td>
		<td>EMAIL</td>
		<td>BANK</td>
		<td>NO AKUN BANK</td>
		<td>NPWP</td>
		<td>NO TELP</td>
		<td>KTP / SIM</td>
		<td>REFERAL</td>
		<td>JATAH AP</td>
		<td>STATUS AKTIF</td>
		<td>STATUS VERIFIKASI</td>
		<td>TANGGAL PENDAFTARAN</td>
	</tr>
';

echo $table_content;

echo '
</table>
';

?>
			