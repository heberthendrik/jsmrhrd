<?php
include('../../library/function_list.php');
?>
<style>
table, tr, td{
	border:1px solid #333;
	border-collapse: collapse;
	padding:5px;
}
</style>
<?php
$query = 
"
select 
v.ID as DEPOSIT__ID,
v.AGENT_ID as DEPOSIT__AGENT_ID,
a.ID as ID,
a.AGENT_ID as AGENT_ID,
a.BRAND_ID as BRAND_ID,
a.SERIAL_NUMBER as SERIAL_NUMBER,
a.VENUE as VENUE,
a.LOCATION_ID as LOCATION_ID,
a.LONGITUDE as LONGITUDE,
a.LATITUDE as LATITUDE,
a.IZIN_LOKASI as IZIN_LOKASI,
a.BUKTI_JARINGAN_TELKOM as BUKTI_JARINGAN_TELKOM,
a.IS_ACTIVE as IS_ACTIVE,
a.DATE_CREATED as DATE_CREATED
from voucher v left join access_point a on a.agent_id = v.agent_id where 1 
";

if( $_POST['AGENT_ID'] != 'All' ){
	
	$query .= " and a.AGENT_ID ".$_POST['AGENT_ID_ARGUMENT']." '".$_POST['AGENT_ID']."' ";
	
}
if( $_POST['BRAND_ID'] != 'All' ){
	
	$query .= " and a.BRAND_ID ".$_POST['BRAND_ID_ARGUMENT']." '".$_POST['BRAND_ID']."' ";
	
}
if( $_POST['SERIAL_NUMBER'] != 'All' && strlen($_POST['SERIAL_NUMBER']) > 0 ){
	
	$query .= " and a.SERIAL_NUMBER ".$_POST['SERIAL_NUMBER_ARGUMENT']." '".$_POST['SERIAL_NUMBER']."' ";
	
}
if( $_POST['VENUE'] != 'All' && strlen($_POST['VENUE']) > 0 ){
	
	$query .= " and a.VENUE ".$_POST['VENUE_ARGUMENT']." '".$_POST['VENUE']."' ";
	
}
if( $_POST['LOCATION_ID'] != 'All' ){
	
	$query .= " and a.LOCATION_ID ".$_POST['LOCATION_ID_ARGUMENT']." '".$_POST['LOCATION_ID']."' ";
	
}
if( $_POST['LONGITUDE'] != 'All' && strlen($_POST['LONGITUDE']) > 0 ){
	
	$query .= " and a.LONGITUDE ".$_POST['LONGITUDE_ARGUMENT']." '".$_POST['LONGITUDE']."' ";
	
}
if( $_POST['LATITUDE'] != 'All' && strlen($_POST['LATITUDE']) > 0 ){
	
	$query .= " and a.LATITUDE ".$_POST['LATITUDE_ARGUMENT']." '".$_POST['LATITUDE']."' ";
	
}
if( $_POST['IZIN_LOKASI'] != 'All' ){

	if( $_POST['IZIN_LOKASI'] == 0 ){
		$query .= " and a.IZIN_LOKASI = '' ";
	} else if( $_POST['IZIN_LOKASI'] == 1 ){
		$query .= " and a.IZIN_LOKASI != '' ";
	}
	
}
if( $_POST['BUKTI_JARINGAN_TELKOM'] != 'All' ){

	if( $_POST['BUKTI_JARINGAN_TELKOM'] == 0 ){
		$query .= " and a.BUKTI_JARINGAN_TELKOM = '' ";
	} else if( $_POST['BUKTI_JARINGAN_TELKOM'] == 1 ){
		$query .= " and a.BUKTI_JARINGAN_TELKOM != '' ";
	}
	
}
if( $_POST['IS_ACTIVE'] != 'All' ){
	
	$query .= " and a.IS_ACTIVE ".$_POST['IS_ACTIVE_ARGUMENT']." '".$_POST['IS_ACTIVE']."' ";
	
}
if( $_POST['IS_APPROVED'] != 'All' ){
	
	$query .= " and a.IS_APPROVED ".$_POST['IS_APPROVED_ARGUMENT']." '".$_POST['IS_APPROVED']."' ";
	
}																	
if( strlen($_POST['DATE_CREATED']) > 0 ){
	
	$query .= " and DATE_FORMAT(a.DATE_CREATED, '%Y %m %d') ".$_POST['DATE_CREATED_ARGUMENT']." DATE_FORMAT('".$_POST['DATE_CREATED']."', '%Y %m %d') ";
	
}












if( $_POST['DEPOSIT__IS_VERIFIED'] != 'All' ){
	
	$query .= " and v.IS_VERIFIED ".$_POST['DEPOSIT__IS_VERIFIED_ARGUMENT']." '".$_POST['DEPOSIT__IS_VERIFIED']."' ";
	
}

if( $_POST['DEPOSIT__IS_ACTIVE'] != 'All' ){
	
	$query .= " and v.IS_ACTIVE ".$_POST['DEPOSIT__IS_ACTIVE_ARGUMENT']." '".$_POST['DEPOSIT__IS_ACTIVE']."' ";
	
}

if( strlen($_POST['DEPOSIT__DATE_CREATED']) > 0 ){
	
	$query .= " and DATE_FORMAT(v.DATE_CREATED, '%Y %m %d') ".$_POST['DEPOSIT__DATE_CREATED_ARGUMENT']." DATE_FORMAT('".$_POST['DEPOSIT__DATE_CREATED']."', '%Y %m %d') ";
	
}

$query .= " order by a.AGENT_ID ASC ";

/* echo $query; */
$result = $db->query($query);
$num = $result->num_rows;

if( $num > 0 ){
	$num = $num;
} else {
	$num = 0;
}

for( $i=0;$i<$num;$i++ ){
	$row = $result->fetch_assoc();
	
	$array_iddeposit = $row['DEPOSIT__ID'];
	$array_idagenpendeposit = $row['DEPOSIT__AGENT_ID'];
	
	$array_id = $row['ID'];
	$array_agentid = stripslashes($row['AGENT_ID']);
	$array_brandid = stripslashes($row['BRAND_ID']);
	$array_serialnumber = stripslashes($row['SERIAL_NUMBER']);
	$array_locationid = stripslashes($row['LOCATION_ID']);
	$array_venue = stripslashes($row['VENUE']);
	$array_address = stripslashes($row['ADDRESS']);
	$array_longitude = stripslashes($row['LONGITUDE']);
	$array_latitude = stripslashes($row['LATITUDE']);
	$array_izinlokasi = stripslashes($row['IZIN_LOKASI']);
	$array_buktijaringantelkom = stripslashes($row['BUKTI_JARINGAN_TELKOM']);
	$array_isactive = stripslashes($row['IS_ACTIVE']);
	$array_isapproved = stripslashes($row['IS_APPROVED']);
	$array_date_created = $row['DATE_CREATED'];
	$array_date_modified = $row['DATE_MODIFIED'];
	
	if( strlen($array_izinlokasi) > 0 ){
		$display_izinlokasi = '<span style="color:green">Ada</span>';
	} else if( strlen($array_izinlokasi) == 0 ){
		$display_izinlokasi = '<span style="color:red">Tidak Ada</span>';
	}
	
	if( strlen($array_buktijaringantelkom) > 0 ){
		$display_buktijaringantelkom = '<span style="color:green">Ada</span>';
	} else if( strlen($array_buktijaringantelkom) == 0 ){
		$display_buktijaringantelkom = '<span style="color:red">Tidak Ada</span>';
	}
	
	if( $array_isactive == 0 ){
		$display_active = '<span style="color:red">Belum aktif</span>';
	} else if( $array_isactive == 1 ){
		$display_active = '<span style="color:green">Sudah aktif</span>';
	} 
	
	if( $array_isapproved == 0 ){
		$display_approval = '<span style="color:red">Belum</span>';
	} else if( $array_isapproved == 1 ){
		$display_approval = '<span style="color:green">Sudah</span>';
	} 
	
	$agen_parameter['ID'] = $array_agentid;
	$function_GetAgentByID = GetAgentByID($agen_parameter);
	
	$brand_parameter['ID'] = $array_brandid;
	$function_GetBrandByID = GetBrandByID($brand_parameter);
	
	$location_parameter['ID'] = $array_locationid;
	$function_GetLocationByID = GetLocationByID($location_parameter);
	
	
	$agen_pendeposit_parameter['ID'] = $array_idagenpendeposit;
	$function_GetAgentPendepositByID = GetAgentByID($agen_pendeposit_parameter);
	
	if( $array_id > 0 ){
		$table_content .=
		'
		<tr>
			<td>'.$array_iddeposit.'</td>
			<td>'.$function_GetAgentPendepositByID['FULL_NAME'][0].'</td>
			
			<td>'.$array_id.'</td>
			<td>'.$function_GetAgentByID['FULL_NAME'][0].'</td>
			<td>'.$function_GetBrandByID['BRAND'][0].'</td>
			<td>'.$array_serialnumber.'</td>
			<td>'.$array_venue.'</td>
			<td>'.$function_GetLocationByID['LOCATION'][0].'</td>
			<td>'.$array_address.'</td>
			<td>'.$array_longitude.'</td>
			<td>'.$array_latitude.'</td>
			<td>'.$display_izinlokasi.'</td>
			<td>'.$display_buktijaringantelkom.'</td>
			<td>'.$display_active.'</td>
			<td>'.$display_approval.'</td>
			<td>'.$array_date_created.'</td>
		</tr>
		';
	} else {
		$decrement_value++;
	}
	
	
}

echo '<p>'.($num-$decrement_value).' data ditemukan</p>';

echo '
<table>
	<tr>
		<td>ID DEPOSIT</td>
		<td>AGEN PENDEPOSIT</td>
		<td>ID</td>
		<td>NAMA AGEN</td>
		<td>MEREK AP</td>
		<td>NOMOR SERI</td>
		<td>NAMA TEMPAT</td>
		<td>LOKASI</td>
		<td>ALAMAT</td>
		<td>LONGITUDE</td>
		<td>LATITUDE</td>
		<td>IZIN LOKASI</td>
		<td>BUKTI JARINGAN TELKOM</td>
		<td>STATUS AKTIF</td>
		<td>STATUS APPROVAL</td>
		<td>TANGGAL INPUT</td>
	</tr>
';

echo $table_content;

echo '
</table>
';

?>
			