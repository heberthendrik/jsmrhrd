<?php
include('../../library/function_list.php');
?>
<style>
table, tr, td{
	border:1px solid #333;
	border-collapse: collapse;
	padding:5px;
}
</style>
<?php
$query = "select * from voucher where 1 ";


if( $_POST['AGENT_ID'] != 'All' ){
	
	$query .= " and AGENT_ID ".$_POST['AGENT_ID_ARGUMENT']." '".$_POST['AGENT_ID']."' ";
	
}

if( $_POST['PRICE_BOUGHT'] != 'All' && strlen($_POST['PRICE_BOUGHT']) > 0 ){
	
	$query .= " and PRICE_BOUGHT ".$_POST['PRICE_BOUGHT_ARGUMENT']." '".$_POST['PRICE_BOUGHT']."' ";
	
}

if( $_POST['QUANTITY_ISSUED'] != 'All' && strlen($_POST['QUANTITY_ISSUED']) > 0 ){
	
	$query .= " and QUANTITY_ISSUED ".$_POST['QUANTITY_ISSUED_ARGUMENT']." '".$_POST['QUANTITY_ISSUED']."' ";
	
}

if( $_POST['BATCH_ID'] != 'All' && strlen($_POST['BATCH_ID']) > 0 ){
	
	$query .= " and BATCH_ID ".$_POST['BATCH_ID_ARGUMENT']." '".$_POST['BATCH_ID']."' ";
	
}

if( $_POST['RECEIPT'] != 'All' ){

	if( $_POST['RECEIPT'] == 0 ){
		$query .= " and RECEIPT = '' ";
	} else if( $_POST['RECEIPT'] == 1 ){
		$query .= " and RECEIPT != '' ";
	}
	
}

if( $_POST['IS_VERIFIED'] != 'All' ){
	
	$query .= " and IS_VERIFIED ".$_POST['IS_VERIFIED_ARGUMENT']." '".$_POST['IS_VERIFIED']."' ";
	
}

if( $_POST['IS_ACTIVE'] != 'All' ){
	
	$query .= " and IS_ACTIVE ".$_POST['IS_ACTIVE_ARGUMENT']." '".$_POST['IS_ACTIVE']."' ";
	
}

if( strlen($_POST['DATE_CREATED']) > 0 ){
	
	$query .= " and DATE_FORMAT(DATE_CREATED, '%Y %m %d') ".$_POST['DATE_CREATED_ARGUMENT']." DATE_FORMAT('".$_POST['DATE_CREATED']."', '%Y %m %d') ";
	
}



$query .= " order by DATE_CREATED DESC ";

/* echo $query; */
$result = $db->query($query);
$num = $result->num_rows;

if( $num > 0 ){
	$num = $num;
} else {
	$num = 0;
}

echo '<p>'.$num.' data ditemukan</p>';

for( $i=0;$i<$num;$i++ ){
	$row = $result->fetch_assoc();
	$array_id = $row['ID'];
	$array_paymentcode = stripslashes($row['PAYMENT_CODE']);
	$array_agentid = stripslashes($row['AGENT_ID']);
	$array_pricebought = stripslashes($row['PRICE_BOUGHT']);
	$array_quantityissued = stripslashes($row['QUANTITY_ISSUED']);
	$array_quantityavailable = stripslashes($row['QUANTITY_AVAILABLE']);
	$array_batchid = stripslashes($row['BATCH_ID']);
	$array_receipt = stripslashes($row['RECEIPT']);
	$array_isverified = stripslashes($row['IS_VERIFIED']);
	$array_isactive = stripslashes($row['IS_ACTIVE']);
	$array_datecreated = stripslashes($row['DATE_CREATED']);
	$array_dateexpired = stripslashes($row['DATE_EXPIRED']);
	
	if( $array_isactive == 0 ){
		$display_active = '<span style="color:red">Belum aktif</span>';
	} else if( $array_isactive == 1 ){
		$display_active = '<span style="color:green">Sudah aktif</span>';
	} 
	
	if( $array_isverified == 0 ){
		$display_verified = '<span style="color:red">Belum Verifikasi Email</span>';
	} else if( $array_isverified == 1 ){
		$display_verified = '<span style="color:green">Sudah Verifikasi Email</span>';
	} 
	
	if( strlen($array_receipt) > 0 ){
		$display_receipt = '<span style="color:green">Ada</span>';
	} else if( strlen($array_receipt) == 0 ){
		$display_receipt = '<span style="color:red">Tidak Ada</span>';
	}
	
	$agen_parameter['ID'] = $array_agentid;
	$function_GetAgentByID = GetAgentByID($agen_parameter);
	
	$table_content .=
	'
	<tr>
		<td>'.$array_id.'</td>
		<td>'.$array_paymentcode.'</td>
		<td>'.$function_GetAgentByID['FULL_NAME'][0].'</td>
		<td>'.$array_pricebought.'</td>
		<td>'.$array_quantityissued.'</td>
		<td>'.$array_batchid.'</td>
		<td>'.$display_receipt.'</td>
		<td>'.$display_active.'</td>
		<td>'.$display_verified.'</td>
		<td>'.$array_datecreated.'</td>
	</tr>
	';
}

echo '
<table>
	<tr>
		<td>ID</td>
		<td>PAYMENT CODE</td>
		<td>NAMA AGEN</td>
		<td>HARGA BELI</td>
		<td>JUMLAH VOUCHER</td>
		<td>BATCH ID</td>
		<td>BUKTI BAYAR</td>
		<td>STATUS AKTIF</td>
		<td>STATUS VERIFIKASI</td>
		<td>TANGGAL DEPOSIT</td>
	</tr>
';

echo $table_content;

echo '
</table>
';

?>
			