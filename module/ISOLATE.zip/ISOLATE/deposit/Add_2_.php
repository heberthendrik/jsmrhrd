<?php include('../include/top_header.php') ?>
			
			<?php
			$input_parameter['ID'] = $_GET['aid'];
			$function_GetReferalSellPriceByAgentID = GetReferalSellPriceByAgentID($input_parameter);
			
			$sell_voucher = $function_GetReferalSellPriceByAgentID['TOTAL_VOUCHER_PRICE'];
			$chain_good = $function_GetReferalSellPriceByAgentID['RESULT'];
			?>			
			
			<div class="inner">
				<!--\\\\\\\ inner start \\\\\\-->
				
				<?php include('../include/navigation_sidebar.php'); ?>
				
				<div class="contentpanel">
					<!--\\\\\\\ contentpanel start\\\\\\-->
					<div class="pull-left breadcrumb_admin clear_both">
						<div class="pull-left page_title theme_color">
							<h1>Master Data Deposit Agen</h1>
						</div>
					</div>

					<div class="container clear_both padding_fix">
						<!--\\\\\\\ container  start \\\\\\-->
						
						<?php include('../include/system_message.php') ?>

						<form action="Process.php" method="post" class="form-horizontal row-border" enctype="multipart/form-data">
						
							<div class="row">
								<div class="col-md-12">
									<div class="block-web">
										<div class="panel-body" style="padding:0px;text-align:right;">
										
											<a href="Add_1_.php"><button type="button" class="btn btn-warning">Kembali</button></a>
											<?php
											if( $chain_good == 1 ){
												?>
												<input type="submit" name="submitSimpan" value="Simpan" class="btn btn-primary" />
												<?php	
											}
											?>
											
										</div>
									</div>
								</div>
							</div>
							
							<?php
							if( $chain_good == 1 ){
								?>
								<div class="alert alert-warning"> Minimal deposit sebanyak 50 voucher setiap bulannya, Anda berhak mendapatkan 1 Access Point. </div>	
								<?php
							} else if($chain_good == 0)  {
								?>
								<div class="alert alert-danger"> Anda tidak bisa melakukan deposit saat ini karena rantai referal Anda terputus. Silahkan hubungi pihak JPU untuk bantuan lebih lanjut. </div>	
								<?php
							}
							?>
							
							<div class="row">
								<div class="col-md-6">
									<div class="block-web">
										<div class="header">
											<div class="actions"> <a class="minimize" href="#"><i class="fa fa-chevron-down"></i></a><a class="close-down" href="#"><i class="fa fa-times"></i></a> </div>
											<h3 class="content-header">Data Deposit (Langkah 2)</h3>
										</div>
										<div class="porlets-content">
											
											<div class="form-group">
												<label class="col-sm-3 control-label">Agen</label>
												<div class="col-sm-9">
													<select class="form-control" id="source" name="selectAgentID" style="background:#eee!important;"  disabled >
														
														<option value=""> --Pilih Agen-- </option>
														
														<?php
														
														$function_GetAllAgent = GetAllAgent();
														
														for( $i=0;$i<$function_GetAllAgent['TOTAL_ROW'];$i++ ){
														
															if( $function_GetAllAgent['ID'][$i] == $_GET['aid'] ){
																$display_indicator = ' selected ';
															} else {
																$display_indicator = '';
															}
														
															?>
															<option value="<?php echo $function_GetAllAgent['ID'][$i]; ?>" <?php echo $display_indicator;?> > <?php echo $function_GetAllAgent['FULL_NAME'][$i]; ?> </option>	
															<?php
														}
														?>	
														
													</select>
												</div>
												<!--/col-sm-9--> 
											</div>
											<div class="form-group">
												<label class="col-sm-3 control-label">Jumlah Voucher</label>
												<div class="col-sm-9">
													<input id="jumlahvoucher" type="number" class="form-control" name="textQuantity" placeholder="Contoh: 15" required min="1" onkeyup="calculateTotalDeposit()" <?php if( $chain_good == 0 ){ echo ' disabled '; } ?> >
												</div>
											</div>
											<div class="form-group">
												<label class="col-sm-3 control-label">Harga per Voucher (IDR)</label>
												<div class="col-sm-9">
													<input id="hargapervoucher" type="number" class="form-control" name="" value="<?php echo $sell_voucher; ?>" disabled >
												</div>
											</div>
											<div class="form-group">
												<label class="col-sm-3 control-label">Total Nilai Deposit</label>
												<div class="col-sm-9">
													<input id="totaldeposit" type="number" class="form-control" disabled >
												</div>
											</div>
										</div>
										<!--/porlets-content-->
									</div>
									<!--/block-web--> 
								</div>
								<!--/col-md-6-->
								
								
								<div class="col-md-6">
									<div class="block-web">
										<div class="header">
											<div class="actions"> <a class="minimize" href="#"><i class="fa fa-chevron-down"></i></a><a class="close-down" href="#"><i class="fa fa-times"></i></a> </div>
											<h3 class="content-header">Rekening Tujuan</h3>
										</div>
										<div class="porlets-content">
											
											<p>Silahkan lakukan pembayaran ke rekening berikut ini:</p>
											<p>
											Bank: BCA
											<br/>Nama: PT. Jagat Praditya Utama
											<br/>Nomor Rekening: 5025466168
											</p>
											<p>
											Pastikan untuk menyimpan bukti transfer, dan upload bukti tersebut melalui form di samping. Terima kasih.
											</p>
											<p>
											Catatan:<br/>
											Untuk mempermudah dan mempercepat verifikasi, mohon tambahkan <strong>Keterangan / Catatan Transaksi</strong> dengan format sebagai berikut:<br/>
											Format: <span style="color:red;"><strong>DPW/DPD [SPASI] Nama</strong></span><br/>
											Contoh: <span style="color:red;">DPD Tangsel Joko Pribadi</span>
											</p>
											
										</div>
										<!--/porlets-content-->
									</div>
									<!--/block-web--> 
								</div>
								<!--/col-md-6-->
								
								
							</div>
							<!--/row--> 
							
							<div class="row">
								<div class="col-md-6">
									<div class="block-web">
										<div class="header">
											<div class="actions"> <a class="minimize" href="#"><i class="fa fa-chevron-down"></i></a><a class="close-down" href="#"><i class="fa fa-times"></i></a> </div>
											<h3 class="content-header">Metode Pembayaran</h3>
										</div>
										<div class="porlets-content">
											<div class="form-group">
												<label class="col-sm-3 control-label">Metode Pembayaran</label>
												<div class="col-sm-9">
													<select class="form-control" id="source" name="selectMetodePembayaran" required >
														
														<option value=""> --Pilih Metode Pembayaran-- </option>
														<option value="transfer_bank">Transfer Bank</option>
<!-- 														<option value="vamandiri">Mandiri</option> -->
<!-- 														<option value="vabni">BNI</option> -->
<!-- 														<option value="vapermata">Permata</option> -->
<!-- 														<option value="finpay021">Telkom</option> -->
														
													</select>
												</div>
												<!--/col-sm-9--> 
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-md-6">
									<div class="block-web">
										<div class="header">
											<div class="actions"> <a class="minimize" href="#"><i class="fa fa-chevron-down"></i></a><a class="close-down" href="#"><i class="fa fa-times"></i></a> </div>
											<h3 class="content-header">Bukti Pembayaran (Untuk Metode Transfer Bank)</h3>
										</div>
										<div class="porlets-content">
											<div class="form-group">
												<label class="col-sm-3 control-label">Bukti Transfer</label>
												<div class="col-sm-9">
													<input type="file" class="form-control" name="fileBuktiTransfer" >
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<input type="hidden" name="HiddenAgentID" value="<?php echo $_GET['aid']; ?>" />
							<input type="hidden" name="HiddenVoucherPrice" value="<?php echo $sell_voucher; ?>" />
							<input type="hidden" name="module" value="DepositAdd" />
						</form>
					</div>
					<!--\\\\\\\ container  end \\\\\\-->
				</div>
				<!--\\\\\\\ content panel end \\\\\\-->
			</div>
			<!--\\\\\\\ inner end\\\\\\-->
		</div>
		<!--\\\\\\\ wrapper end\\\\\\-->
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Compose New Task</h4>
					</div>
					<div class="modal-body"> content </div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary">Save changes</button>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Compose New Task</h4>
					</div>
					<div class="modal-body">sgxdfgxfg </div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary">Save changes</button>
					</div>
				</div>
			</div>
		</div>
		<!-- sidebar chats -->
		<nav class="atm-spmenu atm-spmenu-vertical atm-spmenu-right side-chat">
			<div class="header">
				<input type="text" class="form-control chat-search" placeholder=" Search">
			</div>
			<div href="#" class="sub-header">
				<div class="icon"><i class="fa fa-user"></i></div>
				<p>Online (4)</p>
			</div>
			<div class="content">
				<p class="title">Family</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Steven Smith</a></li>
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> John Doe</a></li>
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Michael Smith</a></li>
					<li class="busy"><a href="#"><i class="fa fa-circle-o"></i> Chris Rogers</a></li>
				</ul>
				<p class="title">Friends</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Vernon Philander</a></li>
					<li class="outside"><a href="#"><i class="fa fa-circle-o"></i> Kyle Abbott</a></li>
					<li><a href="#"><i class="fa fa-circle-o"></i> Dean Elgar</a></li>
				</ul>
				<p class="title">Work</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li><a href="#"><i class="fa fa-circle-o"></i> Dale Steyn</a></li>
					<li><a href="#"><i class="fa fa-circle-o"></i> Morne Morkel</a></li>
				</ul>
			</div>
			<div id="chat-box">
				<div class="header">
					<span>Richard Avedon</span>
					<a class="close"><i class="fa fa-times"></i></a>    
				</div>
				<div class="messages nano nscroller has-scrollbar">
					<div class="content" tabindex="0" style="right: -17px;">
						<ul class="conversation">
							<li class="odd">
								<p>Hi John, how are you?</p>
							</li>
							<li class="text-right">
								<p>Hello I am also fine</p>
							</li>
							<li class="odd">
								<p>Tell me what about you?</p>
							</li>
							<li class="text-right">
								<p>Sorry, I'm late... see you</p>
							</li>
							<li class="odd unread">
								<p>OK, call me later...</p>
							</li>
						</ul>
					</div>
					<div class="pane" style="display: none;">
						<div class="slider" style="height: 20px; top: 0px;"></div>
					</div>
				</div>
				<div class="chat-input">
					<div class="input-group">
						<input type="text" placeholder="Enter a message..." class="form-control">
						<span class="input-group-btn">
						<button class="btn btn-danger" type="button">Send</button>
						</span>      
					</div>
				</div>
			</div>
		</nav>
		<!-- /sidebar chats -->   
		
		<script src="../../repo/js/jquery-2.1.0.js"></script>
		<script src="../../repo/js/bootstrap.min.js"></script>
		<script src="../../repo/js/common-script.js"></script>
		<script src="../../repo/js/jquery.slimscroll.min.js"></script>
		<script type="text/javascript"  src="../../repo/plugins/toggle-switch/toggles.min.js"></script> 
		<script src="../../repo/plugins/checkbox/zepto.js"></script>
		<script src="../../repo/plugins/checkbox/icheck.js"></script>
		<script src="../../repo/js/icheck-init.js"></script>
		<script src="../../repo/js/jquery.slimscroll.min.js"></script>
		<script src="../../repo/js/icheck.js"></script>
		<script type="text/javascript" src="../../repo/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script> 
		<script type="text/javascript" src="../../repo/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script> 
		<script type="text/javascript" src="../../repo/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script> 
		<script type="text/javascript" src="../../repo/plugins/bootstrap-timepicker/js/bootstrap-timepicker.js"></script> 
		<script type="text/javascript" src="../../repo/js/form-components.js"></script> 
		<script type="text/javascript"  src="../../repo/plugins/input-mask/jquery.inputmask.min.js"></script> 
		<script type="text/javascript"  src="../../repo/plugins/input-mask/demo-mask.js"></script> 
		<script type="text/javascript"  src="../../repo/plugins/bootstrap-fileupload/bootstrap-fileupload.min.js"></script> 
		<script type="text/javascript"  src="../../repo/plugins/dropzone/dropzone.min.js"></script> 
		<script type="text/javascript" src="../../repo/plugins/ckeditor/ckeditor.js"></script>
		<script>
			/*==Porlets Actions==*/
			    $('.minimize').click(function(e){
			      var h = $(this).parents(".header");
			      var c = h.next('.porlets-content');
			      var p = h.parent();
			      
			      c.slideToggle();
			      
			      p.toggleClass('closed');
			      
			      e.preventDefault();
			    });
			    
			    $('.refresh').click(function(e){
			      var h = $(this).parents(".header");
			      var p = h.parent();
			      var loading = $('&lt;div class="loading"&gt;&lt;i class="fa fa-refresh fa-spin"&gt;&lt;/i&gt;&lt;/div&gt;');
			      
			      loading.appendTo(p);
			      loading.fadeIn();
			      setTimeout(function() {
			        loading.fadeOut();
			      }, 1000);
			      
			      e.preventDefault();
			    });
			    
			    $('.close-down').click(function(e){
			      var h = $(this).parents(".header");
			      var p = h.parent();
			      
			      p.fadeOut(function(){
			        $(this).remove();
			      });
			      e.preventDefault();
			    });
			
		</script>
		<script src="../../repo/js/jPushMenu.js"></script> 
		<script src="../../repo/js/side-chats.js"></script>

		<script language="JavaScript">
			function calculateTotalDeposit(){
				var hargapervoucher = document.getElementById('hargapervoucher').value;
				var jumlahvoucher = document.getElementById('jumlahvoucher').value;
				var totaldeposit = jumlahvoucher * hargapervoucher;
				document.getElementById("totaldeposit").value=totaldeposit;
			}
			
		</script>
		
	</body>
</html>