<?php include('../../library/function_list.php') ?>
			<style>
				table, th, td {
				   border: 1px solid black;
				}
				table{
					border-collapse: collapse;
				}
			</style>
			
													<table  class="display table table-bordered table-striped" id="dynamic-table">
														<thead>
															<tr>
																<th>ID</th>
																<th>KODE PEMBAYARAN</th>
																<th>BATCH ID</th>
																<th>Nama Agen</th>
																<th>Harga Beli Voucher</th>
																<th>Jumlah Voucher (Beli)</th>
																<th>Jumlah Voucher (Tersedia)</th>
																<th>Bukti Pembayaran</th>
																<th>Status Verifikasi</th>
																<th>Status Aktif</th>
																<th>Tanggal Deposit</th>
															</tr>
														</thead>
														<tbody>
															<?php
															
															$function_GetAllDeposit = GetAllDeposit();
															
															for( $i=0;$i<$function_GetAllDeposit['TOTAL_ROW'];$i++ ){
															
																if( $function_GetAllDeposit['IS_VERIFIED'][$i] == 0 ){
																	$display_ver = '<span style="color:red;">Belum Terverifikasi</span>';
																} else if( $function_GetAllDeposit['IS_VERIFIED'][$i] == 1 ){
																	$display_ver = '<span style="color:green;">Sudah Terverifikasi</span>';
																}
																if( $function_GetAllDeposit['IS_ACTIVE'][$i] == 0 ){
																	$display_aktif = '<span style="color:red;">Belum Aktif</span>';
																} else if( $function_GetAllDeposit['IS_ACTIVE'][$i] == 1 ){
																	$display_aktif = '<span style="color:green;">Sudah Aktif</span>';
																}
																
																if( strlen($function_GetAllDeposit['RECEIPT'][$i]) > 0 ){
																	$display_receipt = '<span style="color:green;">Ada</span>';
																} else if( strlen($function_GetAllDeposit['RECEIPT'][$i]) == 0 ){
																	$display_receipt = '<span style="color:red;">Tidak Ada</span>';
																}
																
																$this_parameter['ID'] = $function_GetAllDeposit['AGENT_ID'][$i];
																$function_GetAgentByID = GetAgentByID($this_parameter);
															
																?>
																<tr>
																	<td><?php echo $function_GetAllDeposit['ID'][$i];?></td>
																	<td><?php echo $function_GetAllDeposit['PAYMENT_CODE'][$i];?></td>
																	<td><?php echo $function_GetAllDeposit['BATCH_ID'][$i];?></td>
																	<td><?php echo $function_GetAgentByID['FULL_NAME'][0];?></td>
																	<td><?php echo $function_GetAllDeposit['PRICE_BOUGHT'][$i];?></td>
																	<td><?php echo $function_GetAllDeposit['QUANTITY_ISSUED'][$i];?></td>
																	<td><?php echo $function_GetAllDeposit['QUANTITY_AVAILABLE'][$i];?></td>
																	<td><?php echo $display_receipt;?></td>
																	<td><?php echo $display_ver;?></td>
																	<td><?php echo $display_aktif;?></td>
																	<td><?php echo $function_GetAllDeposit['DATE_CREATED'][$i];?></td>
																</tr>
																<?php
															}
															?>
														</tbody>
													</table>