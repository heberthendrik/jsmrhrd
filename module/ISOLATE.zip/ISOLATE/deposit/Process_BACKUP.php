<?php

include('../../library/function_list.php');


if( $_POST['module'] == "DepositAdd" ){

	$input_parameter['AGENT_ID'] = $_POST['HiddenAgentID'];
	$input_parameter['PRICE_BOUGHT'] = $_POST['HiddenVoucherPrice'];
	$input_parameter['QUANTITY'] = $_POST['textQuantity'];
	$input_parameter['RECEIPT'] = $_FILES['fileBuktiTransfer'];
	$input_parameter['RECEIPT_NAME'] = $input_parameter['RECEIPT']['name'];
	$nominal = $input_parameter['PRICE_BOUGHT'] * $input_parameter['QUANTITY'];
	
	$metode_pembayaran = $_POST['selectMetodePembayaran'];

	$function_AddDeposit = AddDeposit($input_parameter);
	$deposit_new_id = $function_AddDeposit['NEW_ID'];
	
	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_AddDeposit['RESULT'];
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_AddDeposit['MESSAGE'];

	//UPLOAD PAYMENT RECEIPT
	mkdir('../../media_library/deposit_payment_receipt/'.$deposit_new_id);
	$upload_parameter['TARGET_DIRECTORY'] = '../../media_library/deposit_payment_receipt/'.$deposit_new_id;
	$upload_parameter['IMAGE_FILE'] = $input_parameter['RECEIPT'];
	CustomUploadFile($upload_parameter);
		
	if( $metode_pembayaran == 'transfer_bank' ){
	
		$status_transaksi = '1';
		
		//NOTIFY AGENT FOR DEPOSIT INFO BY EMAIL
		$input_agent_parameter['ID'] = $input_parameter['AGENT_ID'];
		$function_GetAgentByID = GetAgentByID($input_agent_parameter);
		$input_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
		$input_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
		$input_parameter['SUBJECT'] = '[NO REPLY] INFORMASI DEPOSITO TELAH DITERIMA';
		$input_parameter['CONTENT'] = 
		'
		<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
		<p>Data informasi deposito Anda (ID DEPOSIT #'.$deposit_new_id.') telah kami terima dengan detail sebagai berikut:</p>
		<p>
		ID Deposit: <strong>'.$deposit_new_id.'</strong><br/>
		Nama Agen: <strong>'.strtoupper($input_parameter['RECIPIENT_NAME']).'</strong><br/>
		Harga per Voucher (IDR): <strong>'.$input_parameter['PRICE_BOUGHT'].'</strong><br/>
		Jumlah Voucher: <strong>'.$input_parameter['QUANTITY'].'</strong><br/>
		Total Deposit: <strong>'.$nominal.'</strong><br/>
		</p>
		<p>Informasi ini akan kami verifikasi terlebih dahulu ke bank terkait. Hal ini akan membutuhkan waktu kurang lebih 1 hari kerja. Kami akan segera mengkonfirmasikan kepada Anda setelah pembayaran terverifikasi.</p>
		<p>Terima kasih</p>
		';
		
		SendSystemEmail($input_parameter);
		
		//UPDATE PAYMENT CODE JADI CONVENTIONAL
		$query_conv = "update voucher set PAYMENT_CODE = 'conventional' where ID = '".$deposit_new_id."'";
		$result_conv = $db->query($query_conv);
		
		header('Location:Result.php?r=1&id='.$deposit_new_id);		    
	    exit;		
		
	} else {
	
		
		$finpay_customer_parameter['ID'] = $input_parameter['AGENT_ID'];
		$function_GetAgentByID = GetAgentByID($finpay_customer_parameter);
		
		$add_info1 = $function_GetAgentByID['FULL_NAME'][0];
		$amount = $nominal;
		$cust_email = $function_GetAgentByID['EMAIL'][0];
		$cust_id = $function_GetAgentByID['ID'][0];
		$cust_msisdn = $function_GetAgentByID['NO_TELP'][0];
		$cust_name = $function_GetAgentByID['FULL_NAME'][0];
		$invoice = $deposit_new_id;
		$merchant_id = 'JPU848';
		$return_url = 'http://jpu.co.id/jpu_wifiid_central/module/deposit/FinpayTransactionAPI.php';
		$sof_id = $metode_pembayaran;
		$sof_type = 'pay';
		$timeout = 1440;
		$trans_date = date('YmdHis');
		$mer_signature = '';
		
		
		//GENERATE SIGNATURE
		$array_signature[] = $add_info1;
		$array_signature[] = $amount;
		$array_signature[] = $cust_email;
		$array_signature[] = $cust_id;
		$array_signature[] = $cust_msisdn;
		$array_signature[] = $cust_name;
		$array_signature[] = $invoice;
		$array_signature[] = $merchant_id;
		$array_signature[] = $return_url;
		$array_signature[] = $sof_id;
		$array_signature[] = $sof_type;
		$array_signature[] = $timeout;
		$array_signature[] = $trans_date;
		
		//GABUNGIN DENGAN %
		$mer_signature_tahap1 = implode('%', $array_signature);
		
		//UPPERCASE
		$mer_signature_tahap2 = strtoupper($mer_signature_tahap1);
		
		//ADD PASSWORD DI AKHIR TANPA UPPERCASE
		$mer_signature_tahap3 = $mer_signature_tahap2.'%JPU2018';
		
		//HASING
		$mer_signature_tahap4 = hash('sha256', $mer_signature_tahap3);
		
		//FINAL MERCHANT SIGNATURE
		$mer_signature = $mer_signature_tahap4;
	
	
	
	
		// CALL API
		$url = 'https://sandbox.finpay.co.id/servicescode/api/apiFinpay.php';
		$data = array
		(
		'add_info1' => $add_info1,
		'amount' => $amount,
		'cust_email' => $cust_email,
		'cust_id' => $cust_id,
		'cust_msisdn' => $cust_msisdn,
		'cust_name' => $cust_name,
		'invoice' => $invoice,
		'merchant_id' => $merchant_id,
		'return_url' => $return_url,
		'sof_id' => $sof_id,
		'sof_type' => $sof_type,
		'timeout' => $timeout,
		'trans_date' => $trans_date,
		'mer_signature' => $mer_signature
		);
		
		// use key 'http' even if you send the request to https://...
		$options = array(
		    'http' => array(
		        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
		        'method'  => 'POST',
		        'content' => http_build_query($data)
		    )
		);
		//print_r($data);exit;
		$context  = stream_context_create($options);
		$result = file_get_contents($url, false, $context);
		if ($result == FALSE) { 
			/* Handle error */ 
		}
			
		ob_start();
		var_dump($result);
		$response = ob_get_clean();
		$response_finet = $response;
		
		if (strpos($response_finet, 'Success') !== false) {
		    $string = $response_finet;
		    $start = 'payment_code":"';
		    $end = '","redirect_url';
		    
		    $string = ' ' . $string;
		    $ini = strpos($string, $start);
		    if ($ini == 0) return '';
		    $ini += strlen($start);
		    $len = strpos($string, $end, $ini) - $ini;
		    $payment_code =  substr($string, $ini, $len);
		    
		    $status_transaksi = 1;
		    
		    //NOTIFY AGENT FOR DEPOSIT INFO BY EMAIL
			$input_agent_parameter['ID'] = $input_parameter['AGENT_ID'];
			$function_GetAgentByID = GetAgentByID($input_agent_parameter);
			$input_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
			$input_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
			$input_parameter['SUBJECT'] = '[NO REPLY] INFORMASI DEPOSITO TELAH DITERIMA';
			$input_parameter['CONTENT'] = 
			'
			<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
			<p>Data informasi deposito Anda (ID DEPOSIT #'.$deposit_new_id.') telah kami terima dengan detail sebagai berikut:</p>
			<p>
			ID Deposit: <strong>'.$deposit_new_id.'</strong><br/>
			Kode Pembayaran: <strong>'.$payment_code.'</strong><br/>
			Nama Agen: <strong>'.strtoupper($input_parameter['RECIPIENT_NAME']).'</strong><br/>
			Harga per Voucher (IDR): <strong>'.$input_parameter['PRICE_BOUGHT'].'</strong><br/>
			Jumlah Voucher: <strong>'.$input_parameter['QUANTITY'].'</strong><br/>
			Total Deposit: <strong>'.$nominal.'</strong><br/>
			</p>
			<p>Silahkan lakukan pembayaran ke ATM / Alfamart / tempat lainnya yang melayani transaksi Telkom, dengan menggunakan <strong>KODE PEMBAYARAN: '.$payment_code.'</strong>.</p>
			<p>Terima kasih</p>
			';
			
			SendSystemEmail($input_parameter);
		    
		    $query_update_pc = "update voucher set payment_code = '".$payment_code."' where ID = '".$deposit_new_id."'";
		    $result_update_pc = $db->query($query_update_pc);
		    
		    header('Location:Result.php?r=1&id='.$deposit_new_id.'&pc='.$payment_code);		    
		    exit;
		    
		} else {
			$status_transaksi = 0;
			$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = 0;
			$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = 'Proses deposit gagal. Silahkan coba kembali.';
			$query_void = "update voucher set PAYMENT_CODE = 'transaction_failed' where ID = '".$deposit_new_id."'";
			$result_void = $db->query($query_void);
			header('Location:Add_1_.php');
		    exit;
		}
	
	}
	
	exit;
}

else if( $_POST['module'] == "VerifikasiDeposit" ){
	
	$input_parameter['ID'] = $_POST['HiddenCurrentID'];
	$input_parameter['IS_VERIFIED'] = $_POST['selectIsVerified'];
	$function_VerifyDepost = VerifyDeposit($input_parameter);
	
	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_VerifyDepost['RESULT'];
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_VerifyDepost['MESSAGE'];
	
	if( $input_parameter['IS_VERIFIED'] == 1 ){
	
		//KIRIM NOTIFIKASI DEPOSIT SUDAH TERVERIFIKASI
		$function_GetDepositByID = GetDepositByID($input_parameter);
		$agent_id = $function_GetDepositByID['AGENT_ID'][0];
		
		$input_agent_parameter['ID'] = $agent_id;
		$function_GetAgentByID = GetAgentByID($input_agent_parameter);
		$input_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
		$input_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
		$input_parameter['SUBJECT'] = '[NO REPLY] DEPOSIT ANDA TELAH TERVERIFIKASI';
		$input_parameter['CONTENT'] = 
		'
		<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
		<p>Data informasi deposito Anda (ID DEPOSIT #'.$input_parameter['ID'].') telah kami verifikasi. Voucher Anda segera ditambahkan ke dalam inventori Anda dalam beberapa saat lagi.</p>
		<p>Terima kasih</p>
		';
		
		SendSystemEmail($input_parameter);
		
		//ADD AP CREDIT
		if( $function_GetDepositByID['QUANTITY_ISSUED'][0] >= 50 ){
			$function_AddAPCredit = AddAPCredit($input_agent_parameter);	
		}
	
		//GENERATE VOUCHER UNTUK DISERAHKAN KE VIOLET
		$generate_voucher_parameter['AGENT_ID'] = $agent_id;
		$generate_voucher_parameter['TOTAL_VOUCHER'] = $function_GetDepositByID['QUANTITY_ISSUED'][0];
		$function_GenerateMassVoucherByAgentID = GenerateMassVoucherByAgentID($generate_voucher_parameter);
		$produced_batch_id = $function_GenerateMassVoucherByAgentID['PRODUCED_BATCH_ID'];
		
		//UPDATE DATA DEPOSIT UNTUK POINTING BATCH ID DI MASTER VOUCHER
		$query_update = "update voucher set BATCH_ID = '".$produced_batch_id."' where ID = '".$input_parameter['ID']."'";
		$result_update = $db->query($query_update);
		
	}
	
	header('Location:Detail.php?id='.$input_parameter['ID']);
	exit;
}

else if( $_GET['action'] == 'ActivationBatch' ){
	
	$deposit_id = $_GET['id'];
	$input_parameter['BATCH_ID'] = $_GET['bid'];
	$function_ActivateBatch = ActivateBatch($input_parameter);
	
	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_ActivateBatch['RESULT'];
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_ActivateBatch['MESSAGE'];
	
	//KIRIM NOTIFIKASI DEPOSIT SUDAH TERVERIFIKASI
	$get_deposit_parameter['ID'] = $deposit_id;
	$function_GetDepositByID = GetDepositByID($get_deposit_parameter);
	$agent_id = $function_GetDepositByID['AGENT_ID'][0];
	
	$input_agent_parameter['ID'] = $agent_id;
	$function_GetAgentByID = GetAgentByID($input_agent_parameter);
	$input_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
	$input_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
	$input_parameter['SUBJECT'] = '[NO REPLY] DEPOSIT ANDA TELAH TERVERIFIKASI';
	$input_parameter['CONTENT'] = 
	'
	<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
	<p>Voucher Anda (ID DEPOSIT #'.$deposit_id.') telah kami masukan ke dalam akun Anda.</p>
	<p>Masa berlaku voucher ini adalah hingga <strong>'.date('Y-m-d', strtotime('+1 years')).'</strong></p>
	<p>Terima kasih</p>
	';
	
	SendSystemEmail($input_parameter);

	header("Location:Detail.php?id=".$_GET['id']);
	exit;
	
}

?>