<?php include('../../library/function_list.php') ?>
			<style>
				table, th, td {
				   border: 1px solid black;
				}
				table{
					border-collapse: collapse;
				}
			</style>
			
			
			
															<?php
															$function_GetAllDeposit = GetAllDeposit();
															
															for( $i=0;$i<$function_GetAllDeposit['TOTAL_ROW'];$i++ ){
															
																if( $function_GetAllDeposit['IS_VERIFIED'][$i] == 0 ){
																	$display_ver = '<span style="color:red;">Belum Terverifikasi</span>';
																} else if( $function_GetAllDeposit['IS_VERIFIED'][$i] == 1 ){
																	$display_ver = '<span style="color:green;">Sudah Terverifikasi</span>';
																}
																if( $function_GetAllDeposit['IS_ACTIVE'][$i] == 0 ){
																	$display_aktif = '<span style="color:red;">Belum Aktif</span>';
																} else if( $function_GetAllDeposit['IS_ACTIVE'][$i] == 1 ){
																	$display_aktif = '<span style="color:green;">Sudah Aktif</span>';
																}
																
																if( strlen($function_GetAllDeposit['RECEIPT'][$i]) > 0 ){
																	$display_receipt = '<span style="color:green;">Ada</span>';
																} else if( strlen($function_GetAllDeposit['RECEIPT'][$i]) == 0 ){
																	$display_receipt = '<span style="color:red;">Tidak Ada</span>';
																}
																
																$this_parameter['ID'] = $function_GetAllDeposit['AGENT_ID'][$i];
																$function_GetAgentByID = GetAgentByID($this_parameter);
																?>
																<br><br>
																<table style="border:0;">
																	<tr style="border:0;">
																		<td style="border:0;">Nama Agen Pendeposit:</td>
																		<td style="border:0;" colspan="14"><?php echo $function_GetAgentByID['FULL_NAME'][0];?></td>
																	</tr>
																</table>
																<table>
																	<thead>
																		<tr>
																			<th>ID</th>
																			<th>Nama Agen</th>
																			<th>Merk</th>
																			<th>Serial Number</th>
																			<th>Nama Tempat</th>
																			<th>Lokasi</th>
																			<th>Alamat</th>
																			<th>Longitude</th>
																			<th>Latitude</th>
																			<th>Izin Lokasi</th>
																			<th>Bukti Jaringan Telkom</th>
																			<th>Status Aktif</th>
																			<th>Status Approval</th>
																			<th>Tanggal Pendaftaran</th>
																		</tr>
																	</thead>
																	<tbody>
																	<?php
																	
																	$function_GetAllAccessPoint = GetAllAccessPoint();
																	
																	for($j=0;$j<$function_GetAllAccessPoint['TOTAL_ROW'];$j++){
																	
																		if( $function_GetAllAccessPoint['AGENT_ID'][$j] == $function_GetAllDeposit['AGENT_ID'][$i] ){

																			$agent_parameter['ID'] = $function_GetAllAccessPoint['AGENT_ID'][$i];
																			$function_GetAgentByID = GetAgentByID($agent_parameter);
																			
																			$location_parameter['ID'] = $function_GetAllAccessPoint['LOCATION_ID'][$i];
																			$function_GetLocationByID = GetLocationByID($location_parameter);
																		
																			if( $function_GetAllAccessPoint['IS_ACTIVE'][$i] == 1 ){
																				$display_active = '<span style="color:green;">Aktif</span>';
																			} else if( $function_GetAllAccessPoint['IS_ACTIVE'][$i] == 0 ){
																				$display_active = '<span style="color:red;">Tidak Aktif</span>';
																			}
																			
																			if( $function_GetAllAccessPoint['IS_APPROVED'][$i] == 1 ){
																				$display_approval = '<span style="color:green;">Disetujui</span>';
																			} else if( $function_GetAllAccessPoint['IS_APPROVED'][$i] == 0 ){
																				$display_approval = '<span style="color:red;">Belum Disetujui</span>';
																			}
																			
																			if( strlen($function_GetAllAccessPoint['IZIN_LOKASI'][$i]) > 0 ){
																				$display_izinlokasi = '<span style="color:green;">Ada</span>';
																			} else if( strlen($function_GetAllAccessPoint['IZIN_LOKASI'][$i]) == 0 ){
																				$display_izinlokasi = '<span style="color:red;">Belum Ada</span>';
																			}
																			
																			if( strlen($function_GetAllAccessPoint['BUKTI_JARINGAN_TELKOM'][$i]) > 0 ){
																				$display_buktijaringantelkom = '<span style="color:green;">Ada</span>';
																			} else if( strlen($function_GetAllAccessPoint['BUKTI_JARINGAN_TELKOM'][$i]) == 0 ){
																				$display_buktijaringantelkom = '<span style="color:red;">Belum Ada</span>';
																			}
																			
																			$brand_parameter['ID'] = $function_GetAllAccessPoint['BRAND_ID'][$i];
																			$function_GetBrandByID = GetBrandByID($brand_parameter);
																			?>
																			<tr>
																			<td><?php echo $function_GetAllAccessPoint['ID'][$j];?></td>
																			<td><?php echo $function_GetAgentByID['FULL_NAME'][0];?></td>
																			<td><?php echo $function_GetBrandByID['BRAND'][0];?></td>
																			<td><?php echo $function_GetAllAccessPoint['SERIAL_NUMBER'][$j];?></td>
																			<td><?php echo $function_GetAllAccessPoint['VENUE'][$j];?></td>
																			<td><?php echo $function_GetLocationByID['LOCATION'][0];?></td>
																			<td><?php echo $function_GetAllAccessPoint['ADDRESS'][$j];?></td>
																			<td><?php echo $function_GetAllAccessPoint['LONGITUDE'][$j];?></td>
																			<td><?php echo $function_GetAllAccessPoint['LATITUDE'][$j];?></td>
																			<td><?php echo $display_izinlokasi;?></td>
																			<td><?php echo $display_buktijaringantelkom;?></td>
																			<td><?php echo $display_active;?></td>
																			<td><?php echo $display_approval;?></td>
																			<td><?php echo $function_GetAllAccessPoint['DATE_CREATED'][$j];?></td>
																			</tr>
																			<?php
																		}
																	
																	}
																	?>
																	</tbody>
																</table>
																<?php
															
															}
															?>
			
			
			
			
			
			
													<table  class="display table table-bordered table-striped" id="dynamic-table">
														<thead>
															<tr>
																<th colspan="11">DATA AGEN DEPOSIT</th>
																<td style="width:20px;background:#000;">&nbsp;</td>
																<th colspan="14">DATE ACCESS POINT MELEKAT AGEN PENDEPOSIT</th>
															</tr>
															<tr>
																<th>ID</th>
																<th>KODE PEMBAYARAN</th>
																<th>BATCH ID</th>
																<th>Nama Agen</th>
																<th>Harga Beli Voucher</th>
																<th>Jumlah Voucher (Beli)</th>
																<th>Jumlah Voucher (Tersedia)</th>
																<th>Bukti Pembayaran</th>
																<th>Status Verifikasi</th>
																<th>Status Aktif</th>
																<th>Tanggal Deposit</th>
																<td style="width:20px;background:#000;">&nbsp;</td>
																<th>ID</th>
																<th>Nama Agen</th>
																<th>Merk</th>
																<th>Serial Number</th>
																<th>Nama Tempat</th>
																<th>Lokasi</th>
																<th>Alamat</th>
																<th>Longitude</th>
																<th>Latitude</th>
																<th>Izin Lokasi</th>
																<th>Bukti Jaringan Telkom</th>
																<th>Status Aktif</th>
																<th>Status Approval</th>
																<th>Tanggal Pendaftaran</th>
															</tr>
														</thead>
														<tbody>
															<?php
															
															$function_GetAllDeposit = GetAllDeposit();
															
															for( $i=0;$i<$function_GetAllDeposit['TOTAL_ROW'];$i++ ){
															
																if( $function_GetAllDeposit['IS_VERIFIED'][$i] == 0 ){
																	$display_ver = '<span style="color:red;">Belum Terverifikasi</span>';
																} else if( $function_GetAllDeposit['IS_VERIFIED'][$i] == 1 ){
																	$display_ver = '<span style="color:green;">Sudah Terverifikasi</span>';
																}
																if( $function_GetAllDeposit['IS_ACTIVE'][$i] == 0 ){
																	$display_aktif = '<span style="color:red;">Belum Aktif</span>';
																} else if( $function_GetAllDeposit['IS_ACTIVE'][$i] == 1 ){
																	$display_aktif = '<span style="color:green;">Sudah Aktif</span>';
																}
																
																if( strlen($function_GetAllDeposit['RECEIPT'][$i]) > 0 ){
																	$display_receipt = '<span style="color:green;">Ada</span>';
																} else if( strlen($function_GetAllDeposit['RECEIPT'][$i]) == 0 ){
																	$display_receipt = '<span style="color:red;">Tidak Ada</span>';
																}
																
																$this_parameter['ID'] = $function_GetAllDeposit['AGENT_ID'][$i];
																$function_GetAgentByID = GetAgentByID($this_parameter);
															
																
																
																$function_GetAllAccessPoint = GetAllAccessPoint();
																
																for($j=0;$j<$function_GetAllAccessPoint['TOTAL_ROW'];$j++){
																
																	if( $function_GetAllAccessPoint['AGENT_ID'][$j] == $function_GetAllDeposit['AGENT_ID'][$i] ){
																	
																		$current_deposit_id = $function_GetAllDeposit['ID'][$i];
																		
																		?>
																		<tr>
																		
																			<?php
																			if( $current_deposit_id != $previous_deposit_id ){
																				?>
																				<td><?php echo $function_GetAllDeposit['ID'][$i];?></td>
																				<td><?php echo $function_GetAllDeposit['PAYMENT_CODE'][$i];?></td>
																				<td><?php echo $function_GetAllDeposit['BATCH_ID'][$i];?></td>
																				<td><?php echo $function_GetAgentByID['FULL_NAME'][0];?></td>
																				<td><?php echo $function_GetAllDeposit['PRICE_BOUGHT'][$i];?></td>
																				<td><?php echo $function_GetAllDeposit['QUANTITY_ISSUED'][$i];?></td>
																				<td><?php echo $function_GetAllDeposit['QUANTITY_AVAILABLE'][$i];?></td>
																				<td><?php echo $display_receipt;?></td>
																				<td><?php echo $display_ver;?></td>
																				<td><?php echo $display_aktif;?></td>
																				<td><?php echo $function_GetAllDeposit['DATE_CREATED'][$i];?></td>	
																				<?php
																			} else if( $current_deposit_id == $previous_deposit_id ){
																				?>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<td style="background:#eee;">&nbsp;</td>
																				<?php	
																			}
																			?>
																			<td style="width:20px;background:#000;">&nbsp;</td>
																			
																			<?php
																			$agent_parameter['ID'] = $function_GetAllAccessPoint['AGENT_ID'][$i];
																			$function_GetAgentByID = GetAgentByID($agent_parameter);
																			
																			$location_parameter['ID'] = $function_GetAllAccessPoint['LOCATION_ID'][$i];
																			$function_GetLocationByID = GetLocationByID($location_parameter);
																		
																			if( $function_GetAllAccessPoint['IS_ACTIVE'][$i] == 1 ){
																				$display_active = '<span style="color:green;">Aktif</span>';
																			} else if( $function_GetAllAccessPoint['IS_ACTIVE'][$i] == 0 ){
																				$display_active = '<span style="color:red;">Tidak Aktif</span>';
																			}
																			
																			if( $function_GetAllAccessPoint['IS_APPROVED'][$i] == 1 ){
																				$display_approval = '<span style="color:green;">Disetujui</span>';
																			} else if( $function_GetAllAccessPoint['IS_APPROVED'][$i] == 0 ){
																				$display_approval = '<span style="color:red;">Belum Disetujui</span>';
																			}
																			
																			if( strlen($function_GetAllAccessPoint['IZIN_LOKASI'][$i]) > 0 ){
																				$display_izinlokasi = '<span style="color:green;">Ada</span>';
																			} else if( strlen($function_GetAllAccessPoint['IZIN_LOKASI'][$i]) == 0 ){
																				$display_izinlokasi = '<span style="color:red;">Belum Ada</span>';
																			}
																			
																			if( strlen($function_GetAllAccessPoint['BUKTI_JARINGAN_TELKOM'][$i]) > 0 ){
																				$display_buktijaringantelkom = '<span style="color:green;">Ada</span>';
																			} else if( strlen($function_GetAllAccessPoint['BUKTI_JARINGAN_TELKOM'][$i]) == 0 ){
																				$display_buktijaringantelkom = '<span style="color:red;">Belum Ada</span>';
																			}
																			
																			$brand_parameter['ID'] = $function_GetAllAccessPoint['BRAND_ID'][$i];
																			$function_GetBrandByID = GetBrandByID($brand_parameter);
																			?>
																			
																			<td><?php echo $function_GetAllAccessPoint['ID'][$j];?></td>
																			<td><?php echo $function_GetAgentByID['FULL_NAME'][0];?></td>
																			<td><?php echo $function_GetBrandByID['BRAND'][0];?></td>
																			<td><?php echo $function_GetAllAccessPoint['SERIAL_NUMBER'][$j];?></td>
																			<td><?php echo $function_GetAllAccessPoint['VENUE'][$j];?></td>
																			<td><?php echo $function_GetLocationByID['LOCATION'][0];?></td>
																			<td><?php echo $function_GetAllAccessPoint['ADDRESS'][$j];?></td>
																			<td><?php echo $function_GetAllAccessPoint['LONGITUDE'][$j];?></td>
																			<td><?php echo $function_GetAllAccessPoint['LATITUDE'][$j];?></td>
																			<td><?php echo $display_izinlokasi;?></td>
																			<td><?php echo $display_buktijaringantelkom;?></td>
																			<td><?php echo $display_active;?></td>
																			<td><?php echo $display_approval;?></td>
																			<td><?php echo $function_GetAllAccessPoint['DATE_CREATED'][$j];?></td>
																		</tr>
																		<?php
																		
																		$previous_deposit_id = $current_deposit_id;
																				
																	}
																
																	
																}
																
															}
															?>
														</tbody>
													</table>