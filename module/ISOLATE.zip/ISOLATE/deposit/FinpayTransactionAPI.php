<?php

include('../../library/function_list.php');


if( strlen($_POST['mer_signature']) > 0 && $_POST['merchant_id'] = 'JPU848' && $_POST['result_desc'] = 'Success' && $_POST['result_code'] == '00' ){
	
	
	$input_parameter['ID'] = $_POST['invoice'];
	$input_parameter['IS_VERIFIED'] = 1;
	$function_VerifyDepost = VerifyDeposit($input_parameter);
	
	$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_VerifyDepost['RESULT'];
	$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_VerifyDepost['MESSAGE'];
	
	if( $input_parameter['IS_VERIFIED'] == 1 ){
	
		//KIRIM NOTIFIKASI DEPOSIT SUDAH TERVERIFIKASI
		$function_GetDepositByID = GetDepositByID($input_parameter);
		$agent_id = $function_GetDepositByID['AGENT_ID'][0];
		
		$input_agent_parameter['ID'] = $agent_id;
		$function_GetAgentByID = GetAgentByID($input_agent_parameter);
		$input_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
		$input_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
		$input_parameter['SUBJECT'] = '[NO REPLY] DEPOSIT ANDA TELAH TERVERIFIKASI';
		$input_parameter['CONTENT'] = 
		'
		<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
		<p>Data informasi deposito Anda (ID DEPOSIT #'.$input_parameter['ID'].') telah kami verifikasi. Voucher Anda segera ditambahkan ke dalam inventori Anda dalam beberapa saat lagi.</p>
		<p>Terima kasih</p>
		';
		
		SendSystemEmail($input_parameter);	
		
		//ADD AP CREDIT
		if( $function_GetDepositByID['QUANTITY_ISSUED'][0] >= 50 ){
			$function_AddAPCredit = AddAPCredit($input_agent_parameter);	
		}
	
		//GENERATE VOUCHER UNTUK DISERAHKAN KE VIOLET
		$generate_voucher_parameter['AGENT_ID'] = $agent_id;
		$generate_voucher_parameter['TOTAL_VOUCHER'] = $function_GetDepositByID['QUANTITY_ISSUED'][0];
		$function_GenerateMassVoucherByAgentID = GenerateMassVoucherByAgentID($generate_voucher_parameter);
		$produced_batch_id = $function_GenerateMassVoucherByAgentID['PRODUCED_BATCH_ID'];
		
		//UPDATE DATA DEPOSIT UNTUK POINTING BATCH ID DI MASTER VOUCHER
		$query_update = "update voucher set BATCH_ID = '".$produced_batch_id."' where ID = '".$input_parameter['ID']."'";
		$result_update = $db->query($query_update);
		
	}
	
	echo '00';
} else if( strlen($_POST['mer_signature']) > 0 && $_POST['merchant_id'] = 'JPU848' && $_POST['result_desc'] = 'Expired' && $_POST['result_code'] == '05' ){


	$input_parameter['RECIPIENT_EMAIL'] = 'hebert.hendrik@gmail.com';
	$input_parameter['RECIPIENT_NAME'] = 'Hebert Hendrik';
	$input_parameter['SUBJECT'] = 'transaksi expired ID'.$_POST['invoice'];
	$input_parameter['CONTENT'] = 
	'
	Transaksi expired. ID '.$_POST['invoice'].'
	';
	
	SendSystemEmail($input_parameter);	

	$query_update = "update voucher set payment_code = 'transaction_expired' where ID = '".$_POST['invoice']."'";
	$result_update = $db->query($query_update);
	
	echo '05';
	
	

}

else {
	echo 'Error. Please contact JPU admin.';
}

?>