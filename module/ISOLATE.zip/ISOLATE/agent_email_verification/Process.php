<?php

include('../../library/function_list.php');

if( $_GET['action'] == 'x' ){
	
	$input_parameter['ID'] = $_GET['id'];
	$input_parameter['EMAIL'] = $_GET['email'];
	
	$function_GetAgentByID = GetAgentByID($input_parameter);

	if( $function_GetAgentByID['IS_VERIFIED'][0] == 0 ){
		$function_VerifyAgentByEmail = VerifyAgentByEmail($input_parameter);
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = $function_VerifyAgentByEmail['RESULT'];
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = $function_VerifyAgentByEmail['MESSAGE'];
		
		
		//GENERATE RANDOM PASSWORD
		$function_randompassword = GenerateAgentCode();
		$query_update = "update agen set password='".md5($function_randompassword)."' where ID = '".$row_check['ID']."' ";
		$result_update = $db->query($query_update);
		
		//SEND TEMP PASSWORD
		$master_link = GetMasterLink();
		$function_GetAgentByID = GetAgentByID($input_parameter);
		$input_parameter['RECIPIENT_EMAIL'] = $function_GetAgentByID['EMAIL'][0];
		$input_parameter['RECIPIENT_NAME'] = $function_GetAgentByID['FULL_NAME'][0];
		$input_parameter['SUBJECT'] = '[NO REPLY] REGISTRASI AGEN BERHASIL!';
		$input_parameter['CONTENT'] = 
		'
		<p>Kepada '.strtoupper($input_parameter['RECIPIENT_NAME']).',</p>
		<p>Selamat! Anda sudah berhasil terdaftar sebagai agen wifi@id JPU. Silahkan login melalui link dibawah ini untuk masuk ke dalam dashboard Anda.</p>
		<p>'.GetMasterLinkAgenDashboard().'</p>
		<p>Password Anda: <strong>'.$function_randompassword.'</strong></p>
		<p>Terima kasih</p>
		';
		
		SendSystemEmail($input_parameter);
		
		//UPDATE AGEN TEMP PASSWORD
		$temp_password_parameter['PASSWORD'] = md5($function_randompassword);
		$temp_password_parameter['ID'] = $input_parameter['ID'];
		$function_UpdateAgentTempPassword = UpdateAgentTempPassword($temp_password_parameter);
		
		//AUTOMATIC ADD NEW USER FOR LOGIN
		/*
		$input_newuser_parameter['FIRSTNAME'] = $function_GetAgentByID['FULL_NAME'][0];
		$input_newuser_parameter['LASTNAME'] = '';
		$input_newuser_parameter['EMAIL'] = $function_GetAgentByID['EMAIL'][0];
		$input_newuser_parameter['PASSWORD'] = $function_randompassword;
		$input_newuser_parameter['CONFIRM_PASSWORD'] = $function_randompassword;
		$input_newuser_parameter['IS_ACTIVE'] = 1;
		$input_newuser_parameter['MENU_UAC'] = '12,13,14';
		$input_newuser_parameter['SUBMENU_UAC'] = 0;
		*/
		
		//$function_result = AddNewUser($input_newuser_parameter);
	} else if( $function_GetAgentByID['IS_VERIFIED'][0] == 0 ){
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = 1;
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = 'Akun Anda sudah terverifikasi sebelumnya. Proses verifikasi tidak perlu diulangi kembali. Terima kasih';
	} else {
		$_SESSION['HIFEST_FUNCTION_RESULT']['RESULT'] = 0;
		$_SESSION['HIFEST_FUNCTION_RESULT']['MESSAGE'] = 'Proses verifikasi gagal. Silahkan hubungi call center kami. Terima kasih.';
	}
	
	
		
	header("Location:".GetMasterLinkAgenDashboard());
	exit;
	
}

?>