<?php

include('../../library/function_list.php');


if( $_POST['module'] == "SendMessage" ){

	echo $input_parameter['SUBJECT'] = $_POST['textJudulPesan'];
	echo $input_parameter['MESSAGE'] = $_POST['textPesan'];
	
}

?>