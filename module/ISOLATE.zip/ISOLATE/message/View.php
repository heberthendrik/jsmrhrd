<?php include('../include/top_header.php') ?>

			<div class="inner">
				<!--\\\\\\\ inner start \\\\\\-->
				
				<?php include('../include/navigation_sidebar.php'); ?>				
				
				<div class="contentpanel">
					<!--\\\\\\\ contentpanel start\\\\\\-->
					<div class="pull-left breadcrumb_admin clear_both">
						<div class="pull-left page_title theme_color">
							<h1>Pesan</h1>
						</div>
					</div>
					<div class="container clear_both padding_fix">
						<!--\\\\\\\ container  start \\\\\\-->
						<div class="row">
							<div class="col-sm-3 col-lg-2">
								<a class="btn btn-danger btn-block btn-compose-email" href="Add.php">Tulis Pesan</a>
								<ul class="nav nav-pills nav-stacked nav-email">
									<li class="active"> <a href="View.php"> <span class="badge pull-right">2</span> <i class="glyphicon glyphicon-inbox"></i> Kotak Masuk </a> </li>
									<li><a href="#"><i class="glyphicon glyphicon-send"></i> Pesan Terkirim</a></li>
									<li> <a href="#"> <span class="badge pull-right">2</span> <i class="glyphicon glyphicon-folder-open"></i> Pemberitahuan </a> </li>
								</ul>
							</div>
							<!-- col-sm-3 -->
							<div class="col-sm-9 col-lg-10">
								<div class="block-web">
									<div class="pull-right">
										<!--
										<div class="btn-group">
											<button title="" data-toggle="tooltip" type="button" class="btn btn-white tooltips" data-original-title="Archive"><i class="glyphicon glyphicon-hdd"></i></button>
											<button title="" data-toggle="tooltip" type="button" class="btn btn-white tooltips" data-original-title="Report Spam"><i class="glyphicon glyphicon-exclamation-sign"></i></button>
											<button title="" data-toggle="tooltip" type="button" class="btn btn-white tooltips" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></button>
										</div>
										<div class="btn-group">
											<div class="btn-group nomargin">
												<button title="" type="button" class="btn btn-white dropdown-toggle tooltips inbox_btn"  data-toggle="dropdown" data-original-title="Move to Folder"> <i class="glyphicon glyphicon-folder-close"></i> <span class="caret"></span> </button>
												<ul class="dropdown-menu">
													<li><a href="#"><i class="glyphicon glyphicon-folder-open"></i> Conference</a></li>
													<li><a href="#"><i class="glyphicon glyphicon-folder-open"></i> Newsletter</a></li>
													<li><a href="#"><i class="glyphicon glyphicon-folder-open"></i> Invitations</a></li>
													<li><a href="#"><i class="glyphicon glyphicon-folder-open"></i> Promotions</a></li>
												</ul>
											</div>
											<div class="btn-group nomargin">
												<button title="" type="button" class="btn btn-white dropdown-toggle tooltips inbox_btn" data-toggle="dropdown" data-original-title="Label"> <i class="glyphicon glyphicon-tag"></i> <span class="caret"></span> </button>
												<ul class="dropdown-menu">
													<li><a href="#"><i class="glyphicon glyphicon-tag"></i> Web</a></li>
													<li><a href="#"><i class="glyphicon glyphicon-tag"></i> Photo</a></li>
													<li><a href="#"><i class="glyphicon glyphicon-tag"></i> Video</a></li>
												</ul>
											</div>
										</div>
										<div class="btn-group">
											<button type="button" class="btn btn-white"><i class="glyphicon glyphicon-chevron-left"></i></button>
											<button type="button" class="btn btn-white"><i class="glyphicon glyphicon-chevron-right"></i></button>
										</div>
										-->
									</div>
									<strong>Inbox</strong>
									<p class="text-muted">Showing 1 - 15 of 230 messages</p>
									<div class="table-responsive">
										<table class="table table-email">
											<tbody>
												<tr class="unread">
													<td>
														<div class="ckbox ckbox-primary">
															<input type="checkbox" id="checkbox1">
															<label for="checkbox1"></label>
														</div>
													</td>
													<td><a class="star" href=""><i class="glyphicon glyphicon-star"></i></a></td>
													<td>
														<div class="media">
															<a class="pull-left" href="#"> <img class="media-object" src="images/photos/user3.jpg" alt=""> </a>
															<div class="media-body">
																<span class="media-meta pull-right">Today at 7:30am</span>
																<h4 class="text-primary">Mukesh Pradhan</h4>
																<small class="text-muted"></small>
																<p class="email-summary"><strong>UI Status</strong> Vestibulum at feugiat mi. Fusce est turpis... </p>
															</div>
														</div>
													</td>
												</tr>
												<tr>
													<td>
														<div class="ckbox ckbox-primary">
															<input type="checkbox" id="checkbox3">
															<label for="checkbox3"></label>
														</div>
													</td>
													<td><a class="star" href=""><i class="glyphicon glyphicon-star"></i></a></td>
													<td>
														<div class="media">
															<a class="pull-left" href="#"> <img class="media-object" src="images/photos/user1.jpg" alt=""> </a>
															<div class="media-body">
																<span class="media-meta pull-right">Jan 13 at 7:30am</span>
																<h4 class="text-primary">Rajesh Khanna</h4>
																<small class="text-muted"></small>
																<p class="email-summary"><strong>User Interface Conference</strong> Vestibulum at feugiat mi. Fusce est turpis... </p>
															</div>
														</div>
													</td>
												</tr>
											</tbody>
										</table>
									</div>
									<!-- /table-responsive --> 
								</div>
								<!--/ block-web --> 
							</div>
							<!-- /col-sm-9 --> 
						</div>
						<!--/row--> 
					</div>
					<!--\\\\\\\ container  end \\\\\\-->
				</div>
				<!--\\\\\\\ content panel end \\\\\\-->
			</div>
			<!--\\\\\\\ inner end\\\\\\-->
		</div>
		<!--\\\\\\\ wrapper end\\\\\\-->
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Compose New Task</h4>
					</div>
					<div class="modal-body"> content </div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary">Save changes</button>
					</div>
				</div>
			</div>
		</div>
		<!-- sidebar chats -->
		<nav class="atm-spmenu atm-spmenu-vertical atm-spmenu-right side-chat">
			<div class="header">
				<input type="text" class="form-control chat-search" placeholder=" Search">
			</div>
			<div href="#" class="sub-header">
				<div class="icon"><i class="fa fa-user"></i></div>
				<p>Online (4)</p>
			</div>
			<div class="content">
				<p class="title">Family</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Steven Smith</a></li>
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> John Doe</a></li>
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Michael Smith</a></li>
					<li class="busy"><a href="#"><i class="fa fa-circle-o"></i> Chris Rogers</a></li>
				</ul>
				<p class="title">Friends</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li class="online"><a href="#"><i class="fa fa-circle-o"></i> Vernon Philander</a></li>
					<li class="outside"><a href="#"><i class="fa fa-circle-o"></i> Kyle Abbott</a></li>
					<li><a href="#"><i class="fa fa-circle-o"></i> Dean Elgar</a></li>
				</ul>
				<p class="title">Work</p>
				<ul class="nav nav-pills nav-stacked contacts">
					<li><a href="#"><i class="fa fa-circle-o"></i> Dale Steyn</a></li>
					<li><a href="#"><i class="fa fa-circle-o"></i> Morne Morkel</a></li>
				</ul>
			</div>
			<div id="chat-box">
				<div class="header">
					<span>Richard Avedon</span>
					<a class="close"><i class="fa fa-times"></i></a>    
				</div>
				<div class="messages nano nscroller has-scrollbar">
					<div class="content" tabindex="0" style="right: -17px;">
						<ul class="conversation">
							<li class="odd">
								<p>Hi John, how are you?</p>
							</li>
							<li class="text-right">
								<p>Hello I am also fine</p>
							</li>
							<li class="odd">
								<p>Tell me what about you?</p>
							</li>
							<li class="text-right">
								<p>Sorry, I'm late... see you</p>
							</li>
							<li class="odd unread">
								<p>OK, call me later...</p>
							</li>
						</ul>
					</div>
					<div class="pane" style="display: none;">
						<div class="slider" style="height: 20px; top: 0px;"></div>
					</div>
				</div>
				<div class="chat-input">
					<div class="input-group">
						<input type="text" placeholder="Enter a message..." class="form-control">
						<span class="input-group-btn">
						<button class="btn btn-danger" type="button">Send</button>
						</span>      
					</div>
				</div>
			</div>
		</nav>
		<!-- /sidebar chats -->   
		<div class="demo">
			<span id="demo-setting"><i class="fa fa-cog txt-color-blueDark"></i></span> 
			<form>
				<legend class="no-padding margin-bottom-10" style="color:#6e778c;">Layout Options</legend>
				<section><label><input type="checkbox" class="checkbox style-0" id="smart-fixed-header" name="subscription"><span>Fixed Header</span></label><label><input type="checkbox" class="checkbox style-0" id="smart-fixed-navigation" name="terms"><span>Fixed Navigation</span></label><label><input type="checkbox" class="checkbox style-0" id="smart-rigth-navigation" name="terms"><span>Right Navigation</span></label><label><input type="checkbox" class="checkbox style-0" id="smart-boxed-layout" name="terms"><span>Boxed Layout</span></label><span id="smart-bgimages" style="display: none;"></span></section>
				<section>
					<h6 class="margin-top-10 semi-bold margin-bottom-5">Clear Localstorage</h6>
					<a id="reset-smart-widget" class="btn btn-xs btn-block btn-primary" href="javascript:void(0);"><i class="fa fa-refresh"></i> Factory Reset</a>
				</section>
				<h6 class="margin-top-10 semi-bold margin-bottom-5">Ultimo Skins</h6>
				<section id="smart-styles"><a style="background-color:#23262F;" class="btn btn-block btn-xs txt-color-white margin-right-5" id="dark_theme" href="javascript:void(0);"><i id="skin-checked" class="fa fa-check fa-fw"></i> Dark Theme</a><a style="background:#E35154;" class="btn btn-block btn-xs txt-color-white" id="red_thm" href="javascript:void(0);">Red Theme</a><a style="background:#34B077;" class="btn btn-xs btn-block txt-color-darken margin-top-5" id="green_thm" href="javascript:void(0);">Green Theme</a><a style="background:#56A5DB" class="btn btn-xs btn-block txt-color-white margin-top-5" data-skinlogo="img/logo-pale.png" id="blue_thm" href="javascript:void(0);">Blue Theme</a><a style="background:#9C6BAD" class="btn btn-xs btn-block txt-color-white margin-top-5" id="magento_thm" href="javascript:void(0);">Magento Theme</a><a style="background:#FFFFFF" class="btn btn-xs btn-block txt-color-black margin-top-5" id="light_theme" href="javascript:void(0);">Light Theme</a></section>
			</form>
		</div>
		<script src="../../repo/js/jquery-2.1.0.js"></script>
		<script src="../../repo/js/bootstrap.min.js"></script>
		<script src="../../repo/js/common-script.js"></script>
		<script src="../../repo/js/jquery.slimscroll.min.js"></script>
		<script src="../../repo/plugins/data-tables/jquery.dataTables.js"></script>
		<script src="../../repo/plugins/data-tables/DT_bootstrap.js"></script>
		<script src="../../repo/plugins/data-tables/dynamic_table_init.js"></script>
		<script src="../../repo/plugins/edit-table/edit-table.js"></script>
		<script>
			jQuery(document).ready(function() {
			    EditableTable.init();
			});
		</script>
		<script src="../../repo/js/jPushMenu.js"></script> 
		<script src="../../repo/js/side-chats.js"></script>
	</body>
</html>