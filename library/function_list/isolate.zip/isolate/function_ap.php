<?php

/*==========================================

/*==========================================*/

function AddAccessPoint($input_parameter){
	global $db;
	
	$query_check = 
	"
	select
		count(ac.ID) as total_row
	from access_point ac
	where
		ac.SERIAL_NUMBER = '".addslashes($input_parameter['SERIAL_NUMBER'])."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Serial Number (".$input_parameter['SERIAL_NUMBER'].") telah digunakan. Silahkan mencoba kembali dengan serial number yang lain.";
	} else {
	
		$query_add = 
		"
		insert into access_point
		(
		AGENT_ID,
		BRAND_ID,
		SERIAL_NUMBER,
		LOCATION_ID,
		VENUE,
		ADDRESS,
		LONGITUDE,
		LATITUDE,
		IZIN_LOKASI,
		BUKTI_JARINGAN_TELKOM,
		IS_ACTIVE,
		IS_APPROVED,
		DATE_CREATED,
		DATE_MODIFIED
		)
		values
		(
		'".addslashes($input_parameter['AGENT_ID'])."',
		'".addslashes($input_parameter['BRAND_ID'])."',
		'".addslashes($input_parameter['SERIAL_NUMBER'])."',
		'".addslashes($input_parameter['LOCATION_ID'])."',
		'".addslashes($input_parameter['VENUE'])."',
		'".addslashes($input_parameter['ADDRESS'])."',
		'".addslashes($input_parameter['LONGITUDE'])."',
		'".addslashes($input_parameter['LATITUDE'])."',
		'".addslashes($input_parameter['IZIN_LOKASI']['name'])."',
		'".addslashes($input_parameter['BUKTI_JARINGAN_TELKOM']['name'])."',
		'".addslashes($input_parameter['IS_ACTIVE'])."',
		'".addslashes($input_parameter['IS_APPROVED'])."',
		'".date('Y-m-d H:i:s')."',
		'".date('Y-m-d H:i:s')."'
		)
		";
		$result_add = $db->query($query_add);
	
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Access Point telah berhasil ditambahkan." ;
		$function_result['NEW_ID'] = $db->insert_id;
	}
	
	//DECREASE AP CREDIT
	//$query_update = "update agen set AP_CREDIT = (AP_CREDIT - 1) where ID = '".$input_parameter['AGENT_ID']."'";
	//$result_update = $db->query($query_update);
	
	return $function_result;
}

function UpdateAccessPointByID($input_parameter){
	global $db;
	
	$query_check = 
	"
	select
		count(ac.ID) as total_row
	from access_point ac
	where
		ac.SERIAL_NUMBER = '".addslashes($input_parameter['SERIAL_NUMBER'])."'
		and ac.ID != '".$input_parameter['ID']."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Serial Number (".$input_parameter['SERIAL_NUMBER'].") telah digunakan. Silahkan mencoba kembali dengan serial number yang lain.";
	} else {
	
		$query_update = 
		"
		update
			access_point ac
		set
			ac.BRAND_ID = '".addslashes($input_parameter['BRAND_ID'])."',
			ac.SERIAL_NUMBER = '".addslashes($input_parameter['SERIAL_NUMBER'])."',
			ac.LOCATION_ID = '".addslashes($input_parameter['LOCATION_ID'])."',
			ac.VENUE = '".addslashes($input_parameter['VENUE'])."',
			ac.ADDRESS = '".addslashes($input_parameter['ADDRESS'])."',
			ac.LONGITUDE = '".addslashes($input_parameter['LONGITUDE'])."',
			ac.LATITUDE = '".addslashes($input_parameter['LATITUDE'])."',
			ac.IS_ACTIVE = '".addslashes($input_parameter['IS_ACTIVE'])."',
			ac.IS_APPROVED = '".addslashes($input_parameter['IS_APPROVED'])."',
			ac.DATE_MODIFIED = '".date('Y-m-d H:i:s')."'
		where
			ac.ID = '".$input_parameter['ID']."'
		";
		$result_update = $db->query($query_update);
	
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Data access point telah berhasil diperbaharui." ;
	}
	
	return $function_result;
}

function DeleteAccessPointByID($input_parameter){
	global $db;
	
	$query_delete = 
	"
	delete 
	from access_point
	where ID = '".$input_parameter['ID']."'
	";
	$result_delete = $db->query($query_delete);
	
	//DELETE MEDIA
	$delete_dir = '../../media_library/bukti_jaringan_telkom/'.$input_parameter['ID'];
	rrmdir($delete_dir);
	$delete_dir = '../../media_library/izin_lokasi_ap/'.$input_parameter['ID'];
	rrmdir($delete_dir);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Data access point telah berhasil dihapus.";
	
	return $function_result;
}

function GetAccessPointByID($input_parameter){
	global $db;
	
	$query_get = "select * from access_point where ID = '".$input_parameter['ID']."' ";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentid[] = stripslashes($row_get['AGENT_ID']);
		$array_brandid[] = stripslashes($row_get['BRAND_ID']);
		$array_serialnumber[] = stripslashes($row_get['SERIAL_NUMBER']);
		$array_locationid[] = stripslashes($row_get['LOCATION_ID']);
		$array_venue[] = stripslashes($row_get['VENUE']);
		$array_address[] = stripslashes($row_get['ADDRESS']);
		$array_longitude[] = stripslashes($row_get['LONGITUDE']);
		$array_latitude[] = stripslashes($row_get['LATITUDE']);
		$array_izinlokasi[] = stripslashes($row_get['IZIN_LOKASI']);
		$array_buktijaringantelkom[] = stripslashes($row_get['BUKTI_JARINGAN_TELKOM']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_isapproved[] = stripslashes($row_get['IS_APPROVED']);
		$array_date_created[] = $row_get['DATE_CRATED'];
		$array_date_modified[] = $row_get['DATE_MODIFIED'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['BRAND_ID'] = $array_brandid;
	$grand_array['SERIAL_NUMBER'] = $array_serialnumber;
	$grand_array['LOCATION_ID'] = $array_locationid;
	$grand_array['VENUE'] = $array_venue;
	$grand_array['ADDRESS'] = $array_address;
	$grand_array['LONGITUDE'] = $array_longitude;
	$grand_array['LATITUDE'] = $array_latitude;
	$grand_array['IZIN_LOKASI'] = $array_izinlokasi;
	$grand_array['BUKTI_JARINGAN_TELKOM'] = $array_buktijaringantelkom;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['IS_APPROVED'] = $array_isapproved;
	$grand_array['DATE_CREATED'] = $array_date_created;
	$grand_array['DATE_MODIFIED'] = $array_date_modified;
	
	return $grand_array;

}

function GetAllAccessPoint(){
	global $db;
	
	$query_get = "select * from access_point";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentid[] = stripslashes($row_get['AGENT_ID']);
		$array_brandid[] = stripslashes($row_get['BRAND_ID']);
		$array_serialnumber[] = stripslashes($row_get['SERIAL_NUMBER']);
		$array_locationid[] = stripslashes($row_get['LOCATION_ID']);
		$array_venue[] = stripslashes($row_get['VENUE']);
		$array_address[] = stripslashes($row_get['ADDRESS']);
		$array_longitude[] = stripslashes($row_get['LONGITUDE']);
		$array_latitude[] = stripslashes($row_get['LATITUDE']);
		$array_izinlokasi[] = stripslashes($row_get['IZIN_LOKASI']);
		$array_buktijaringantelkom[] = stripslashes($row_get['BUKTI_JARINGAN_TELKOM']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_isapproved[] = stripslashes($row_get['IS_APPROVED']);
		$array_date_created[] = $row_get['DATE_CREATED'];
		$array_date_modified[] = $row_get['DATE_MODIFIED'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['BRAND_ID'] = $array_brandid;
	$grand_array['SERIAL_NUMBER'] = $array_serialnumber;
	$grand_array['LOCATION_ID'] = $array_locationid;
	$grand_array['VENUE'] = $array_venue;
	$grand_array['ADDRESS'] = $array_address;
	$grand_array['LONGITUDE'] = $array_longitude;
	$grand_array['LATITUDE'] = $array_latitude;
	$grand_array['IZIN_LOKASI'] = $array_izinlokasi;
	$grand_array['BUKTI_JARINGAN_TELKOM'] = $array_buktijaringantelkom;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['IS_APPROVED'] = $array_isapproved;
	$grand_array['DATE_CREATED'] = $array_date_created;
	$grand_array['DATE_MODIFIED'] = $array_date_modified;
	
	return $grand_array;
}

function EmptyAccessPoint(){
	global $db;
	
	$query_empty = 
	"
	truncate access_point;
	";
	$result_empty = $db->query($query_empty);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Semua data access point telah berhasil dihapus.";
	
	return $function_result;
}

function UseAPCredit($input_parameter){
	
	global $db;
	
	$query_update = "update agen set AP_CREDIT = (AP_CREDIT - 1) where ID = '".$input_parameter['AGENT_ID']."'";
	$result_update = $db->query($query_update);
	
}

function GetTotalAccessPoint(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from access_point";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_ap = $row_get['total_row'];
	
	return $total_ap;
	
}

function GetTotalAccessActive(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from access_point where is_active = 1";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_ap = $row_get['total_row'];
	
	return $total_ap;
	
}

function GetTotalAccessNonActive(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from access_point where is_active = 0";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_ap = $row_get['total_row'];
	
	return $total_ap;
	
}

function GetTotalAccessApproved(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from access_point where is_approved = 1";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_ap = $row_get['total_row'];
	
	return $total_ap;
	
}

function GetTotalAccessNotApproved(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from access_point where is_approved = 0";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_ap = $row_get['total_row'];
	
	return $total_ap;
	
}

function UpdateBuktiJaringanTelkomByID($input_parameter){
	
	global $db;
	
	
	
}


?>