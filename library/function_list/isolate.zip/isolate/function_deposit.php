<?php

/*==========================================

/*==========================================*/

function AddDeposit($input_parameter){
	global $db;
	
	$query_add = 
	"
	insert into voucher
	(
	AGENT_ID,
	PRICE_BOUGHT,
	QUANTITY_ISSUED,
	RECEIPT,
	IS_VERIFIED,
	DATE_CREATED
	)
	values
	(
	'".addslashes($input_parameter['AGENT_ID'])."',
	'".addslashes($input_parameter['PRICE_BOUGHT'])."',
	'".addslashes($input_parameter['QUANTITY'])."',
	'".addslashes($input_parameter['RECEIPT_NAME'])."',
	'0',
	'".date('Y-m-d H:i:s')."'
	)
	";
	$result_add = $db->query($query_add);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Data deposit voucher telah berhasil ditambahkan." ;
	$function_result['NEW_ID'] = $db->insert_id;
	
	$log_parameter['MODULE'] = 'deposit';
	$log_parameter['MESSAGE'] = '[USER ID: '.$_SESSION['JPU_WIFIID']['USER_ID'].'] menambahkan data deposit untuk [AGEN ID: '.$input_parameter['AGENT_ID'].'], harga beli [PRICE_BOUGHT: '.$input_parameter['PRICE_BOUGHT'].'], jumlah voucher [QUANTITY: '.$input_parameter['QUANTITY'].'], nama file bukti pembayaran [RECEIPT_NAME: '.$input_parameter['RECEIPT_NAME'].']. Final ID DEPOSIT: '.$function_result['NEW_ID'];
	AddLog($log_parameter);
	
	/*
	$query_update = 
	"
	update voucher 
	set 
		DATE_EXPIRED = DATE_ADD(DATE_EXPIRED, INTERVAL 1 YEAR)
	where
		ID = '".$function_result['NEW_ID']."'
	";
	$result_update = $db->query($query_update);
	*/
	
	
	return $function_result;
}

function DeleteDepositByID($input_parameter){
	global $db;
	
	//DELETE DEPOSIT
	$query_delete = 
	"
	delete 
	from voucher
	where ID = '".$input_parameter['ID']."'
	and AGENT_ID = '".$input_parameter['AGENT_ID']."'
	";
	$result_delete = $db->query($query_delete);
	
	//DELETE MEDIA
	$delete_dir = '../../media_library/deposit_payment_receipt/'.$input_parameter['ID'];
	rrmdir($delete_dir);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Data voucher telah berhasil dihapus.";
	
	return $function_result;
}

function GetDepositByID($input_parameter){
	global $db;
	
	$query_get = "select * from voucher where ID = '".$input_parameter['ID']."' ";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_paymentcode[] = stripslashes($row_get['PAYMENT_CODE']);
		$array_agentid[] = stripslashes($row_get['AGENT_ID']);
		$array_pricebought[] = stripslashes($row_get['PRICE_BOUGHT']);
		$array_quantityissued[] = stripslashes($row_get['QUANTITY_ISSUED']);
		$array_quantityavailable[] = stripslashes($row_get['QUANTITY_AVAILABLE']);
		$array_batchid[] = stripslashes($row_get['BATCH_ID']);
		$array_receipt[] = stripslashes($row_get['RECEIPT']);
		$array_isverified[] = stripslashes($row_get['IS_VERIFIED']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_datecreated[] = stripslashes($row_get['DATE_CREATED']);
		$array_dateexpired[] = stripslashes($row_get['DATE_EXPIRED']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['PAYMENT_CODE'] = $array_paymentcode;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['PRICE_BOUGHT'] = $array_pricebought;
	$grand_array['QUANTITY_ISSUED'] = $array_quantityissued;
	$grand_array['QUANTITY_AVAILABLE'] = $array_quantityavailable;
	$grand_array['BATCH_ID'] = $array_batchid;
	$grand_array['RECEIPT'] = $array_receipt;
	$grand_array['IS_VERIFIED'] = $array_isverified;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	$grand_array['DATE_EXPIRED'] = $array_dateexpired;
	
	return $grand_array;

}

function GetAllDeposit(){
	global $db;
	
	$query_get = "select * from voucher";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_paymentcode[] = stripslashes($row_get['PAYMENT_CODE']);
		$array_agentid[] = stripslashes($row_get['AGENT_ID']);
		$array_pricebought[] = stripslashes($row_get['PRICE_BOUGHT']);
		$array_quantityissued[] = stripslashes($row_get['QUANTITY_ISSUED']);
		$array_quantityavailable[] = stripslashes($row_get['QUANTITY_AVAILABLE']);
		$array_batchid[] = stripslashes($row_get['BATCH_ID']);
		$array_receipt[] = stripslashes($row_get['RECEIPT']);
		$array_isverified[] = stripslashes($row_get['IS_VERIFIED']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_datecreated[] = stripslashes($row_get['DATE_CREATED']);
		$array_dateexpired[] = stripslashes($row_get['DATE_EXPIRED']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['PAYMENT_CODE'] = $array_paymentcode;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['PRICE_BOUGHT'] = $array_pricebought;
	$grand_array['QUANTITY_ISSUED'] = $array_quantityissued;
	$grand_array['QUANTITY_AVAILABLE'] = $array_quantityavailable;
	$grand_array['BATCH_ID'] = $array_batchid;
	$grand_array['RECEIPT'] = $array_receipt;
	$grand_array['IS_VERIFIED'] = $array_isverified;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	$grand_array['DATE_EXPIRED'] = $array_dateexpired;
	
	return $grand_array;
}

function EmptyDeposit(){
	global $db;
	
	$query_empty = 
	"
	truncate voucher;
	";
	$result_empty = $db->query($query_empty);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Semua voucher telah berhasil dihapus.";
	
	return $function_result;
}

function VerifyDeposit($input_parameter){
	
	global $db;
	
	$query_update = 
	"
	update voucher 
		set IS_VERIFIED = '".$input_parameter['IS_VERIFIED']."'
	where 
		ID = '".$input_parameter['ID']."'
	";
	$result_update = $db->query($query_update);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Deposit telah berhasil diverifikasi.";
	
	
	/*
	//GET AGENT BY DEPOSIT ID
	$deposit_parameter['ID'] = $input_parameter['ID'];
	$function_GetDepositByID = GetDepositByID($deposit_parameter);
	
	
	
	//BOOK VOUCHER
	$query_get = 
	"
	select * 
	from master_voucher 
	where 
		IS_ACTIVE = 1
		AND IS_BOOKED = 0
	order by
		ID ASC
	";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$function_GetDepositByID['QUANTITY_ISSUED'][0];$i++ ){
		$row_get = $result_get->fetch_assoc();
		
		$query_book = "update master_voucher set AGENT_ID = '".$function_GetDepositByID['AGENT_ID'][0]."', IS_BOOKED = '1' where ID = '".$row_get['ID']."'";
		$result_book = $db->query($query_book);
	}
	*/
	
	return $function_result;
	
}

function GetTotalAvailableVoucher($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		SUM(QUANTITY_AVAILABLE) as total_voucher_available 
	from
		voucher
	where 
		AGENT_ID = '".$input_parameter['AGENT_ID']."' 
		AND IS_VERIFIED = 1 
		AND IS_ACTIVE = 1
		AND DATE_EXPIRED >= '".date('Y-m-d')."' 
	";
	//echo $query_get;exit;
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_voucher_available = $row_get['total_voucher_available'];
	
	return $total_voucher_available;
	
}

function GetEarliestAvailableVoucherID($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select * 
	from 
		voucher 
	where 
		AGENT_ID = '".$input_parameter['AGENT_ID']."' 
		and IS_VERIFIED = 1 
		and IS_ACTIVE = 1
		and QUANTITY_AVAILABLE > 0
		and DATE_EXPIRED >= '".date('Y-m-d')."'
	order by 
		DATE_EXPIRED ASC
	limit
		0,1
	";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$voucher_id = $row_get['ID'];
	
	return $voucher_id;
	
}

function AddAPCredit($input_parameter){
	
	global $db;
	
	$query_update = "update agen set AP_CREDIT = (AP_CREDIT + 1) where ID = '".$input_parameter['ID']."'";
	$result_update = $db->query($query_update);
	
}

function CekReadyStockVoucherCentral(){
	
	global $db;
	
	$query_get = "select count(ID) as TOTAL_AVAILABLE from master_voucher where IS_ACTIVE = 1 and IS_BOOKED = 0";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$available_voucher = $row_get['TOTAL_AVAILABLE'];
	
	return $available_voucher;
	
}

function GetTotalVoucherGenerated(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from master_voucher";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_voucher = $row_get['total_row'];
	
	return $total_voucher;
	
}

function GetTotalVoucherAvailableForSale(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from master_voucher where is_bought = 0 and is_active = 1";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_voucher = $row_get['total_row'];
	
	return $total_voucher;
	
}

function GetTotalVoucherSold(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from master_voucher where is_bought = 1 and is_active = 1";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_voucher = $row_get['total_row'];
	
	return $total_voucher;
	
}

function GetTotalVoucherExpired(){
	
	global $db;
	
	$query_get = "select sum(quantity_available) as total_row from voucher where date_expired < CURDATE() ";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_voucher = $row_get['total_row'];
	
	return $total_voucher;
	
}

function GetTotalDataDeposit(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from voucher";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_deposit = $row_get['total_row'];
	
	return $total_deposit;
	
}

function GetTotalNonVerifiedDeposit(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from voucher where is_verified = 0";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_deposit = $row_get['total_row'];
	
	return $total_deposit;
	
}

function GetTotalNonActiveDeposit(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from voucher where is_active = 0";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_deposit = $row_get['total_row'];
	
	return $total_deposit;
	
}

function GetTotalNonInProcessActivationDeposit(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from voucher where is_verified = 1 and is_active = 0";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_deposit = $row_get['total_row'];
	
	return $total_deposit;
	
}

?>