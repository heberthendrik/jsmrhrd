<?php

/*==========================================

/*==========================================*/

function AddAgent($input_parameter){
	global $db;
	
	$query_check = 
	"
	select
		count(a.ID) as total_row
	from agen a
	where
		a.EMAIL = '".addslashes($input_parameter['EMAIL'])."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Email (".$input_parameter['EMAIL'].") telah digunakan. Silahkan mencoba kembali dengan email yang lain.";
	} else {
	
		// TAMBAH MASTER DATA AGENT
		$query_add = 
		"
		insert into agen
		(
		FULL_NAME,
		EMAIL,
		BANK_ID,
		BANK_ACCOUNT_NO,
		NPWP,
		NO_TELP,
		NO_KTP_SIM,
		REFERAL_ID,
		IS_ACTIVE,
		IS_VERIFIED,
		DATE_CREATED,
		DATE_MODIFIED
		)
		values
		(
		'".addslashes($input_parameter['FULL_NAME'])."',
		'".addslashes($input_parameter['EMAIL'])."',
		'".addslashes($input_parameter['BANK_ID'])."',
		'".addslashes($input_parameter['BANK_ACCOUNT_NO'])."',
		'".addslashes($input_parameter['NPWP'])."',
		'".addslashes($input_parameter['NO_TELP'])."',
		'".addslashes($input_parameter['NO_KTP_SIM'])."',
		'".addslashes($input_parameter['REFERAL_ID'])."',
		'".addslashes($input_parameter['IS_ACTIVE'])."',
		'".addslashes($input_parameter['IS_VERIFIED'])."',
		'".date('Y-m-d H:i:s')."',
		'".date('Y-m-d H:i:s')."'
		)
		";
		//echo $query_add;exit;
		$result_add = $db->query($query_add);
	
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Agen telah berhasil ditambahkan." ;
		$function_result['NEW_ID'] = $db->insert_id;
		
	}
	
	return $function_result;
}

function UpdateAgentByID($input_parameter){
	global $db;
	
	$query_check = 
	"
	select
		count(a.ID) as total_row
	from agen a
	where
		a.EMAIL = '".addslashes($input_parameter['EMAIL'])."'
		and a.ID != '".$input_parameter['ID']."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Email (".$input_parameter['EMAIL'].") telah digunakan. Silahkan mencoba kembali dengan email yang lain.";
	} else {
	
		$query_update = 
		"
		update
			agen a
		set
			a.FULL_NAME = '".addslashes($input_parameter['FULL_NAME'])."',
			a.EMAIL = '".addslashes($input_parameter['EMAIL'])."',
			a.BANK_ID = '".addslashes($input_parameter['BANK_ID'])."',
			a.BANK_ACCOUNT_NO = '".addslashes($input_parameter['BANK_ACCOUNT_NO'])."',
			a.NPWP = '".addslashes($input_parameter['NPWP'])."',
			a.NO_TELP = '".addslashes($input_parameter['NO_TELP'])."',
			a.NO_KTP_SIM = '".addslashes($input_parameter['NO_KTP_SIM'])."',
			a.REFERAL_ID = '".addslashes($input_parameter['REFERAL_ID'])."',
			a.IS_ACTIVE = '".addslashes($input_parameter['IS_ACTIVE'])."',
			a.IS_VERIFIED = '".addslashes($input_parameter['IS_VERIFIED'])."',
			a.DATE_MODIFIED = '".date('Y-m-d H:i:s')."'
		where
			a.ID = '".$input_parameter['ID']."'
		";
		$result_update = $db->query($query_update);
		
/* 		echo $query_update;exit; */
		
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Data agen telah berhasil diperbaharui." ;
	}
	
	return $function_result;
}

function DeleteAgentByID($input_parameter){
	global $db;
	
	$query_delete = 
	"
	delete 
	from agen
	where ID = '".$city_metadata['ID']."'
	";
	$result_delete = $db->query($query_delete);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Data agen telah berhasil dihapus.";
	
	return $function_result;
}

function GetAgentByID($input_parameter){
	global $db;
	
	$query_get = "select * from agen where ID = '".$input_parameter['ID']."' ";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentcode[] = stripslashes($row_get['AGENT_CODE']);
		$array_fullname[] = stripslashes($row_get['FULL_NAME']);
		$array_email[] = stripslashes($row_get['EMAIL']);
		$array_bankid[] = stripslashes($row_get['BANK_ID']);
		$array_bankaccountno[] = stripslashes($row_get['BANK_ACCOUNT_NO']);
		$array_npwp[] = stripslashes($row_get['NPWP']);
		$array_notelp[] = stripslashes($row_get['NO_TELP']);
		$array_noktpsim[] = stripslashes($row_get['NO_KTP_SIM']);
		$array_referalid[] = stripslashes($row_get['REFERAL_ID']);
		$array_apcredit[] = stripslashes($row_get['AP_CREDIT']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_isverified[] = stripslashes($row_get['IS_VERIFIED']);
		$array_date_created[] = $row_get['DATE_CRATED'];
		$array_date_modified[] = $row_get['DATE_MODIFIED'];
	}
	//echo $query_get;exit;
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_CODE'] = $array_agentcode;
	$grand_array['FULL_NAME'] = $array_fullname;
	$grand_array['EMAIL'] = $array_email;
	$grand_array['BANK_ID'] = $array_bankid;
	$grand_array['BANK_ACCOUNT_NO'] = $array_bankaccountno;
	$grand_array['NPWP'] = $array_npwp;
	$grand_array['NO_TELP'] = $array_notelp;
	$grand_array['NO_KTP_SIM'] = $array_noktpsim;
	$grand_array['REFERAL_ID'] = $array_referalid;
	$grand_array['AP_CREDIT'] = $array_apcredit;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['IS_VERIFIED'] = $array_isverified;
	$grand_array['DATE_CREATED'] = $array_date_created;
	$grand_array['DATE_MODIFIED'] = $array_date_modified;
	
	return $grand_array;
}

function GetAgentByEmail($input_parameter){
	global $db;
	
	$query_get = "select * from agen where EMAIL = '".$input_parameter['EMAIL']."' ";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentcode[] = stripslashes($row_get['AGENT_CODE']);
		$array_fullname[] = stripslashes($row_get['FULL_NAME']);
		$array_email[] = stripslashes($row_get['EMAIL']);
		$array_bankid[] = stripslashes($row_get['BANK_ID']);
		$array_bankaccountno[] = stripslashes($row_get['BANK_ACCOUNT_NO']);
		$array_npwp[] = stripslashes($row_get['NPWP']);
		$array_notelp[] = stripslashes($row_get['NO_TELP']);
		$array_noktpsim[] = stripslashes($row_get['NO_KTP_SIM']);
		$array_referalid[] = stripslashes($row_get['REFERAL_ID']);
		$array_apcredit[] = stripslashes($row_get['AP_CREDIT']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_isverified[] = stripslashes($row_get['IS_VERIFIED']);
		$array_date_created[] = $row_get['DATE_CRATED'];
		$array_date_modified[] = $row_get['DATE_MODIFIED'];
	}
	//echo $query_get;exit;
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_CODE'] = $array_agentcode;
	$grand_array['FULL_NAME'] = $array_fullname;
	$grand_array['EMAIL'] = $array_email;
	$grand_array['BANK_ID'] = $array_bankid;
	$grand_array['BANK_ACCOUNT_NO'] = $array_bankaccountno;
	$grand_array['NPWP'] = $array_npwp;
	$grand_array['NO_TELP'] = $array_notelp;
	$grand_array['NO_KTP_SIM'] = $array_noktpsim;
	$grand_array['REFERAL_ID'] = $array_referalid;
	$grand_array['AP_CREDIT'] = $array_apcredit;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['IS_VERIFIED'] = $array_isverified;
	$grand_array['DATE_CREATED'] = $array_date_created;
	$grand_array['DATE_MODIFIED'] = $array_date_modified;
	
	return $grand_array;
}

function GetAllAgent(){
	global $db;
	
	$query_get = "select * from agen order by FULL_NAME ASC";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentcode[] = stripslashes($row_get['AGENT_CODE']);
		$array_fullname[] = stripslashes($row_get['FULL_NAME']);
		$array_email[] = stripslashes($row_get['EMAIL']);
		$array_bankid[] = stripslashes($row_get['BANK_ID']);
		$array_bankaccountno[] = stripslashes($row_get['BANK_ACCOUNT_NO']);
		$array_npwp[] = stripslashes($row_get['NPWP']);
		$array_notelp[] = stripslashes($row_get['NO_TELP']);
		$array_noktpsim[] = stripslashes($row_get['NO_KTP_SIM']);
		$array_referalid[] = stripslashes($row_get['REFERAL_ID']);
		$array_apcredit[] = stripslashes($row_get['AP_CREDIT']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_isverified[] = stripslashes($row_get['IS_VERIFIED']);
		$array_date_created[] = $row_get['DATE_CREATED'];
		$array_date_modified[] = $row_get['DATE_MODIFIED'];
	}
	//echo $query_get;exit;
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_CODE'] = $array_agentcode;
	$grand_array['FULL_NAME'] = $array_fullname;
	$grand_array['EMAIL'] = $array_email;
	$grand_array['BANK_ID'] = $array_bankid;
	$grand_array['BANK_ACCOUNT_NO'] = $array_bankaccountno;
	$grand_array['NPWP'] = $array_npwp;
	$grand_array['NO_TELP'] = $array_notelp;
	$grand_array['NO_KTP_SIM'] = $array_noktpsim;
	$grand_array['REFERAL_ID'] = $array_referalid;
	$grand_array['AP_CREDIT'] = $array_apcredit;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['IS_VERIFIED'] = $array_isverified;
	$grand_array['DATE_CREATED'] = $array_date_created;
	$grand_array['DATE_MODIFIED'] = $array_date_modified;
	
	return $grand_array;
}

function EmptyAgent(){
	global $db;
	
	$query_empty = 
	"
	truncate agen;
	";
	$result_empty = $db->query($query_empty);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Semua data agen telah berhasil dihapus.";
	
	return $function_result;
}

function GetAllDownlineAgent($input_parameter){
	
	global $db;
	
	$query_get = "select * from agen where REFERAL_ID = '".$input_parameter['ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	
	return $grand_array;
	
}

function GetAllGrandDownlineAgent($input_parameter){
	
	global $db;
	
	//QUERY GENERATE TREE TEMP TABLE BASED ON USER ID
	$query_get_1st = "select * from agen where REFERAL_ID = '".$input_parameter['ID']."'";
	$result_get_1st = $db->query($query_get_1st);
	$num_get_1st = $result_get_1st->num_rows;
	
	for($i=0;$i<$num_get_1st;$i++){
		$row_get_1st = $result_get_1st->fetch_assoc();
		$query_add = 
		"
		insert into 
		temp_downline
		(
		REQUESTER_ID,
		ROOT_AGENT_ID,
		ID,
		PARENT_ID
		)
		values
		(
		'".$_SESSION['JPU_WIFIID_AGEN']['USER_ID']."',
		'".$input_parameter['ID']."',
		'".$row_get_1st['ID']."',
		'0'
		)
		";
		//echo $query_add;exit;
		$result_add = $db->query($query_add);
	}
	
	
	for( $i=0;$i<2;$j++ ){
		$query_get_turunan = "select * from temp_downline where ROOT_AGENT_ID = '".$input_parameter['ID']."' and IS_CLEAR = 0 limit 0,1";
		$result_get_turunan = $db->query($query_get_turunan);
		$num_get_turunan = $result_get_turunan->num_rows;
		
		if( $num_get_turunan > 0 ){
			$row_get_turunan = $result_get_turunan->fetch_assoc();
			
			//MASUKIN TURUNANNYA
			$query_get_turunan_dari_turunan = " select * from agen where REFERAL_ID = '".$row_get_turunan['ID']."' ";
			$result_get_turunan_dari_turunan = $db->query($query_get_turunan_dari_turunan);
			$num_get_turunan_dari_turunan = $result_get_turunan_dari_turunan->num_rows;
			
			if( $num_get_turunan_dari_turunan > 0 ){
			
				for( $x=0;$x<$num_get_turunan_dari_turunan;$x++ ){
					$row_get_turunan_dari_turunan = $result_get_turunan_dari_turunan->fetch_assoc();
					
					$query_insert = 
					"
					insert into 
					temp_downline
					(
					REQUESTER_ID,
					ROOT_AGENT_ID,
					ID,
					PARENT_ID
					)
					values
					(
					'".$_SESSION['JPU_WIFIID_AGEN']['USER_ID']."',
					'".$input_parameter['ID']."',
					'".$row_get_turunan_dari_turunan['ID']."',
					'".$row_get_turunan['ID']."'
					)
					";
					$result_insert = $db->query($query_insert);	
				}
				
			}
			
			$query_update = "update temp_downline set IS_CLEAR = 1 where id = '".$row_get_turunan['ID']."' and ROOT_AGENT_ID = '".$input_parameter['ID']."' and REQUESTER_ID = '".$_SESSION['JPU_WIFIID_AGEN']['USER_ID']."' ";
			$result_update = $db->query($query_update);
		}	
		else if($num_get_turunan == 0){
			break;
		}
	}
	
	$query_summary = "select * from temp_downline where root_agent_id = '".$input_parameter['ID']."' and requester_id = '".$_SESSION['JPU_WIFIID_AGEN']['USER_ID']."' ";
	$result_summary = $db->query($query_summary);
	$num_summary = $result_summary->num_rows;
	
	for( $i=0;$i<$num_summary;$i++ ){
		$row_summary = $result_summary->fetch_assoc();
		$array_id[] = $row_summary['ID'];
	}
	
	$grand_array = $array_id;
	
	
	$query_delete = "delete from temp_downline where root_agent_id = '".$input_parameter['ID']."' and requester_id = '".$_SESSION['JPU_WIFIID_AGEN']['USER_ID']."'";
	$result_delete = $db->query($query_delete);
	
	return $grand_array;
	
}







// COMISSION

function AddComissionHistory($input_parameter){
	global $db;
	
	
	$query_check = 
	"
	select
		count(ch.ID) as total_row
	from comission_history ch
	where
		ch.DATE_EFFECTIVE = '".addslashes($input_parameter['DATE_EFFECTIVE'])."'
		and AGENT_ID = '".addslashes($input_parameter['ID'])."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
	
		$query_update = 
		"
		update comission_history
		set
		COMISSION = '".addslashes($input_parameter['COMISSION'])."'
		where
		DATE_EFFECTIVE = '".addslashes($input_parameter['DATE_EFFECTIVE'])."'
		";
		$result_update = $db->query($query_update);
	
	} else {
		// TAMBAH COMISSION HISTORY
		$query_add = 
		"
		insert into comission_history
		(
		AGENT_ID,
		COMISSION,
		DATE_EFFECTIVE
		)
		values
		(
		'".addslashes($input_parameter['ID'])."',
		'".addslashes($input_parameter['COMISSION'])."',
		'".addslashes($input_parameter['DATE_EFFECTIVE'])."'
		)
		";
		$result_add = $db->query($query_add);
	}
	
}

function GetCurrentComissionbyAgentID($input_parameter){
	
	global $db;

	$query_get = 
	"
	select 
		* 
	from 
		comission_history 
	where 
		AGENT_ID = '".addslashes($input_parameter['ID'])."'
		and DATE_EFFECTIVE <= '".date('Y-m-d')."'
	ORDER BY
		DATE_EFFECTIVE DESC
	limit 0,1
	";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$current_comission = $row_get['COMISSION'];
	
	$function_result['COMISSION'] = $current_comission;
	
	return $function_result;
	
}

function UpdateLatestComission($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		* 
	from 
		comission_history 
	where 
		AGENT_ID = '".$input_parameter['AGENT_ID']."' 
	order by 
		DATE_EFFECTIVE DESC 
	limit 0,1
	";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$latest_comission_id = $row_get['ID'];
	
}

function GetAllComissionHistoryByAgentID($input_parameter){
	
	global $db;
	
	$query_get = "select * from comission_history where AGENT_ID = '".$input_parameter['AGENT_ID']."' order by DATE_EFFECTIVE DESC";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_dateeffective[] = $row_get['DATE_EFFECTIVE'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_EFFECTIVE'] = $array_dateeffective;
	
	return $grand_array;
	
}









// SELL PRICE

function AddSellPriceHistory($input_parameter){
	global $db;
	
	
	$query_check = 
	"
	select
		count(sph.ID) as total_row
	from sell_price_history sph
	where
		sph.DATE_EFFECTIVE = '".addslashes($input_parameter['DATE_EFFECTIVE'])."'
		and sph.AGENT_ID = '".addslashes($input_parameter['ID'])."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
	
		$query_update = 
		"
		update sell_price_history
		set
		SELL_PRICE = '".addslashes($input_parameter['SELL_PRICE'])."'
		where
		DATE_EFFECTIVE = '".addslashes($input_parameter['DATE_EFFECTIVE'])."'
		";
		$result_update = $db->query($query_update);
	
	} else {
		// TAMBAH SELL PRICE HISTORY
		$query_add = 
		"
		insert into sell_price_history
		(
		AGENT_ID,
		SELL_PRICE,
		DATE_EFFECTIVE
		)
		values
		(
		'".addslashes($input_parameter['ID'])."',
		'".addslashes($input_parameter['SELL_PRICE'])."',
		'".addslashes($input_parameter['DATE_EFFECTIVE'])."'
		)
		";
		//echo $query_add;exit;
		$result_add = $db->query($query_add);
	}
	
}

function GetCurrentSellPricebyAgentID($input_parameter){
	
	global $db;

	$query_get = 
	"
	select 
		* 
	from 
		sell_price_history 
	where 
		AGENT_ID = '".addslashes($input_parameter['ID'])."'
		and DATE_EFFECTIVE <= '".date('Y-m-d')."'
	ORDER BY
		DATE_EFFECTIVE DESC
	limit 0,1
	";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$current_sell_price = $row_get['SELL_PRICE'];
	
	$function_result['SELL_PRICE'] = $current_sell_price;
	
	return $function_result;
	
}

function UpdateLatestSellPrice($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		* 
	from 
		sell_price_history 
	where 
		AGENT_ID = '".$input_parameter['AGENT_ID']."' 
	order by 
		DATE_EFFECTIVE DESC 
	limit 0,1
	";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$latest_sell_price_id = $row_get['ID'];
	
	
	
}

function GetAllSellPriceHistoryByAgentID($input_parameter){
	
	global $db;
	
	$query_get = "select * from sell_price_history where AGENT_ID = '".$input_parameter['AGENT_ID']."' order by DATE_EFFECTIVE DESC";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_sellprice[] = $row_get['SELL_PRICE'];
		$array_dateeffective[] = $row_get['DATE_EFFECTIVE'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['SELL_PRICE'] = $array_sellprice;
	$grand_array['DATE_EFFECTIVE'] = $array_dateeffective;
	
	return $grand_array;
	
}

function GetSellPriceByID($input_parameter){
	
	global $db;
	
	$query_get = "select * from sell_price_history where ID = '".$input_parameter['ID']."' ";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$sell_price = $row_get['SELL_PRICE'];
	
	return $sell_price;
	
}

function GetReferalSellPriceByAgentID($input_parameter){
	
	global $db;
	
	$chain_broken = 0;
	
	for($i=0;$i<2;$j++){
		
		//GET REFERAL ID	
		$current_agent_id = $input_parameter['ID'];
		$input_parameter_currentagent['ID'] = $current_agent_id;
		$function_GetAgentByID = GetAgentByID($input_parameter_currentagent);
		$referal_id = $function_GetAgentByID['REFERAL_ID'][0];	
		
		//GET CURRENT REFERAL COMISSION
		$input_parameter_currentcomission['ID'] = $referal_id;
		$referal_comission = GetCurrentComissionbyAgentID($input_parameter_currentcomission);
		$array_referal_comission[] = $referal_comission['COMISSION'];
		
		//CHANGE CURRENT AGENT ID TO REFERAL ID
		$input_parameter['ID'] = $input_parameter_currentcomission['ID'];
		
		if( $input_parameter['ID'] == 769 ){
			break;
		}
		
		else if( $input_parameter['ID'] == 0 ){
			$chain_broken = 1;
			break;
		}
		
	}
	
	$sum_comission = array_sum($array_referal_comission);
	
	$master_setting_parameter['PARAMETER'] = 'MASTER_SELL_PRICE';
	$function_GetMasterPrice = GetMasterSetting($master_setting_parameter);
	
	$total_voucher_price = $sum_comission + $function_GetMasterPrice;

	if( $chain_broken == 0 ){
		$grand_array['RESULT'] = 1;
		$grand_array['TOTAL_VOUCHER_PRICE'] = $total_voucher_price;	
	} else if( $chain_broken == 1 ) {
		$grand_array['RESULT'] = 0;
		$grand_array['TOTAL_VOUCHER_PRICE'] = 999999;
	}
	
	return $grand_array;
	
}



















// AGENT CODE

function AssignAgentCode($input_parameter){
	
	global $db;
	
	for( $i=0;$i<2;$j++ ){
	
		$agent_code = $input_parameter['AGENT_CODE_PARAMETER'].'-';
		$agent_code_randomized = GenerateAgentCode();
		$new_complete_agent_code = $agent_code.$agent_code_randomized;
		$input_parameter_check['SUGGESTED_AGENT_CODE'] = $new_complete_agent_code;
		
		if( CheckDuplicateAgentCode($input_parameter_check) == 0 ){
			break;
		}
		
	}
	
	$query_update = "update agen set AGENT_CODE = '".$input_parameter_check['SUGGESTED_AGENT_CODE']."' where ID = '".$input_parameter['ID']."'";
	$result = $db->query($query_update);
	
}

function GenerateAgentCode(){
	
	$str = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
	
	for( $i=0;$i<5;$i++ ){
		$agent_code .= $str[rand(0, strlen($str)-1)];
	}
	
	return $agent_code;
	
}

function CheckDuplicateAgentCode($input_parameter){
	
	global $db;
	
	$query_check = "select count(ID) as total_row from agen where agent_code = '".$input_parameter['SUGGESTED_AGENT_CODE']."'";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	
	if( $row_check['total_row'] == 1 ){
		return 1;
	} else if( $row_check['total_row'] == 0 ) {
		return 0;
	}
	
}

function GetAgentByAgentCode($input_parameter){
	
	global $db;
	
	$query_get = "select ID from agen where AGENT_CODE = '".$input_parameter['AGENT_CODE']."'";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	
	return $row_get['ID'];
	
}

function VerifyAgentByEmail($input_parameter){
	
	global $db;
	
	$query_check = "select ID, EMAIL, FULL_NAME from agen where ID = '".$input_parameter['ID']."' and email = '".$input_parameter['EMAIL']."'";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	
	if( $row_check['ID'] > 0 ){
		
		//UPDATE STATUS
		$query_update = "update agen set is_verified = 1 where ID = '".$row_check['ID']."'";
		$result_update = $db->query($query_update);
		
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Verifikasi berhasil! Silahkan login menggunakan email sementara yang sudah dikirimkan ke email Anda.";
		
	} else {
		
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Verifikasi data gagal! Email atau ID agen tidak terdaftar!";
		
	}
	
	return $function_result;
	
}

function UpdateAgentTempPassword($input_parameter){
	
	global $db;
	
	$query_update = "update agen set PASSWORD = '".$input_parameter['PASSWORD']."' where ID = '".$input_parameter['ID']."'";
	$result_update = $db->query($query_update);
	
}







// AUTOMATIC ASSIGN AGENT CODE

function asdf(){
	
	global $db;
	
	$query_getall = "select * from agen";
	$result_getall = $db->query($query_getall);
	$num_getall = $result_getall->num_rows;
	
	for( $i=0;$i<$num_getall;$i++ ){
		$row_getall = $result_getall->fetch_assoc();
		
		$input_parameter['AGENT_CODE_PARAMETER'] = 'IAMPKL';
		$input_parameter['ID'] = $row_getall['ID'];
		AssignAgentCode($input_parameter);
		
	}
	
}




// DASHBOARD

function GetTotalAgentRegistered(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from agen";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_agen = $row_get['total_row'];
	
	return $total_agen;
	
}

function GetTotalAgentActive(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from agen where is_active = 1";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_agen = $row_get['total_row'];
	
	return $total_agen;
	
}

function GetTotalAgentNonActive(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from agen where is_active = 0";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_agen = $row_get['total_row'];
	
	return $total_agen;
	
}

function GetTotalAgentNotVerified(){
	
	global $db;
	
	$query_get = "select count(id) as total_row from agen where is_verified = 0";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$total_agen = $row_get['total_row'];
	
	return $total_agen;
	
}

?>