<?php

/*==========================================

/*==========================================*/

function AddAgentCode($input_parameter){
	global $db;
	
	$query_check = 
	"
	select
		count(ac.ID) as total_row
	from agent_code ac
	where
		ac.AGENT_CODE = '".addslashes($input_parameter['AGENT_CODE'])."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Kode Agen (".$input_parameter['AGENT_CODE'].") telah digunakan. Silahkan mencoba kembali dengan kode agen yang lain.";
	} else {
	
		$query_add = 
		"
		insert into agent_code
		(
		AGENT_CODE
		)
		values
		(
		'".addslashes($input_parameter['AGENT_CODE'])."'
		)
		";
		$result_add = $db->query($query_add);
	
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Kode agen telah berhasil ditambahkan." ;
		$function_result['NEW_ID'] = $db->insert_id;
	}
	
	return $function_result;
}




function UpdateAgentCodeByID($input_parameter){
	global $db;
	
	$query_check = 
	"
	select
		count(ac.ID) as total_row
	from agent_code ac
	where
		ac.AGENT_CODE = '".addslashes($input_parameter['AGENT_CODE'])."'
		and ac.ID != '".$input_parameter['ID']."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Kode Agen (".$input_parameter['AGENT_CODE'].") telah digunakan. Silahkan mencoba kembali dengan kode agen yang lain.";
	} else {
	
		$query_update = 
		"
		update
			agent_code ac
		set
			ac.AGENT_CODE = '".addslashes($input_parameter['AGENT_CODE'])."'
		where
			ac.ID = '".$input_parameter['ID']."'
		";
		$result_update = $db->query($query_update);
	
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Data kode agen telah berhasil diperbaharui." ;
	}
	
	return $function_result;
}




function DeleteAgentCodeByID($input_parameter){
	global $db;
	
	$query_delete = 
	"
	delete 
	from agent_code
	where ID = '".$input_parameter['ID']."'
	";
	$result_delete = $db->query($query_delete);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Data kode agen telah berhasil dihapus.";
	
	return $function_result;
}




function GetAgentCodeByID($input_parameter){
	global $db;
	
	$query_get = "select * from agent_code where ID = '".$input_parameter['ID']."' ";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentcode[] = stripslashes($row_get['AGENT_CODE']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_CODE'] = $array_agentcode;
	
	return $grand_array;

}




function GetAllAgentCode(){
	global $db;
	
	$query_get = "select * from agent_code";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentcode[] = stripslashes($row_get['AGENT_CODE']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_CODE'] = $array_agentcode;
	
	return $grand_array;
}




function EmptyAgentCode(){
	global $db;
	
	$query_empty = 
	"
	truncate agent_code;
	";
	$result_empty = $db->query($query_empty);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Semua kode agen telah berhasil dihapus.";
	
	return $function_result;
}





?>