<?php

function BroadcastMessage($input_parameter){
	
	global $db;
	
	$function_GetAllAgent = GetAllAgent();
	
	$query_get = "select max(broadcast_id) as last_broadcast_id from message_broadcast";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$last_broadcast_id = $row_get['last_broadcast_id'];
	$next_broadcast_id = $last_broadcast_id+1;
	
	for( $i=0;$i<$function_GetAllAgent['TOTAL_ROW'];$i++ ){
		$agent_id = $function_GetAllAgent['ID'][$i];
		
		$query_add = "
		insert into message_broadcast
		(
		BROADCAST_ID,
		CENTRAL_USER_ID,
		RECIPIENT_AGENT_ID,
		SUBJECT,
		MESSAGE,
		DATE_CREATED
		)
		values
		(
		'".$next_broadcast_id."',
		'".$_SESSION['JPU_WIFIID']['USER_ID']."',
		'".$agent_id."',
		'".$input_parameter['SUBJECT']."',
		'".$input_parameter['MESSAGE']."',
		'".date('Y-m-d H:i:s')."'
		)
		";
		$result_add = $db->query($query_add);
	}
	
}

function GetAllBroadcastForCentral(){
	
	global $db;
	
	$query_get = "select * from message_broadcast group by broadcast_id order by broadcast_id desc";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_broadcastid[] = $row_get['BROADCAST_ID'];
		$array_centraluserid[] = $row_get['CENTRAL_USER_ID'];
		$array_recipientagentid[] = $row_get['RECIPIENT_AGENT_ID'];
		$array_subject[] = $row_get['SUBJECT'];
		$array_message[] = $row_get['MESSAGE'];
		$array_isread[] = $row_get['IS_READ'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['BROADCAST_ID'] = $array_broadcastid;
	$grand_array['CENTRAL_USER_ID'] = $array_centraluserid;
	$grand_array['RECIPIENT_AGENT_ID'] = $array_recipientagentid;
	$grand_array['SUBJECT'] = $array_subject;
	$grand_array['MESSAGE'] = $array_message;
	$grand_array['IS_READ'] = $array_isread;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	
	return $grand_array;
	
}

function GetAllBroadcast(){
	
	global $db;
	
	$query_get = "select * from message_broadcast order by broadcast_id desc";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_broadcastid[] = $row_get['BROADCAST_ID'];
		$array_centraluserid[] = $row_get['CENTRAL_USER_ID'];
		$array_recipientagentid[] = $row_get['RECIPIENT_AGENT_ID'];
		$array_subject[] = $row_get['SUBJECT'];
		$array_message[] = $row_get['MESSAGE'];
		$array_isread[] = $row_get['IS_READ'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['BROADCAST_ID'] = $array_broadcastid;
	$grand_array['CENTRAL_USER_ID'] = $array_centraluserid;
	$grand_array['RECIPIENT_AGENT_ID'] = $array_recipientagentid;
	$grand_array['SUBJECT'] = $array_subject;
	$grand_array['MESSAGE'] = $array_message;
	$grand_array['IS_READ'] = $array_isread;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	
	return $grand_array;
	
}

function GetBroadcastByID($input_parameter){
	
	global $db;
	
	$query_get = "select * from message_broadcast where id = '".$input_parameter['ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_broadcastid[] = $row_get['BROADCAST_ID'];
		$array_centraluserid[] = $row_get['CENTRAL_USER_ID'];
		$array_recipientagentid[] = $row_get['RECIPIENT_AGENT_ID'];
		$array_subject[] = $row_get['SUBJECT'];
		$array_message[] = $row_get['MESSAGE'];
		$array_isread[] = $row_get['IS_READ'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['BROADCAST_ID'] = $array_broadcastid;
	$grand_array['CENTRAL_USER_ID'] = $array_centraluserid;
	$grand_array['RECIPIENT_AGENT_ID'] = $array_recipientagentid;
	$grand_array['SUBJECT'] = $array_subject;
	$grand_array['MESSAGE'] = $array_message;
	$grand_array['IS_READ'] = $array_isread;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	
	return $grand_array;
	
}

function GetAllBroadcastByAgentID($input_parameter){
	
	global $db;
	
	$query_get = "select * from message_broadcast where RECIPIENT_AGENT_ID = '".$input_parameter['RECIPIENT_AGENT_ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_broadcastid[] = $row_get['BROADCAST_ID'];
		$array_centraluserid[] = $row_get['CENTRAL_USER_ID'];
		$array_recipientagentid[] = $row_get['RECIPIENT_AGENT_ID'];
		$array_subject[] = $row_get['SUBJECT'];
		$array_message[] = $row_get['MESSAGE'];
		$array_isread[] = $row_get['IS_READ'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['BROADCAST_ID'] = $array_broadcastid;
	$grand_array['CENTRAL_USER_ID'] = $array_centraluserid;
	$grand_array['RECIPIENT_AGENT_ID'] = $array_recipientagentid;
	$grand_array['SUBJECT'] = $array_subject;
	$grand_array['MESSAGE'] = $array_message;
	$grand_array['IS_READ'] = $array_isread;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	
	return $grand_array;
	
}

?>