<?php

/*==========================================

/*==========================================*/

function GenerateMassVoucher($input_parameter){
	global $db;
	
	$total_voucher = $input_parameter['TOTAL_VOUCHER'];
	$kode_unik_username = $input_parameter['KODE_UNIK_USERNAME'];
	
	$function_GetLastProductionBatch = GetLastProductionBatch();
	$nextbatch = $function_GetLastProductionBatch + 1;
	
	for( $i=0;$i<$total_voucher;$i++ ){
		
		$query_add = 
		"
		insert into
			master_voucher
		(
		BATCH_ID,
		DATE_CREATED
		)
		values
		(
		'".$nextbatch."',
		'".date('Y-m-d H:i:s')."'
		)
		";
		$result_add = $db->query($query_add);
		$this_voucher_id = $db->insert_id;
		
		$assign_username_parameter['ID'] = $this_voucher_id;
		$assign_username_parameter['NEXT_BATCH'] = $nextbatch;
		$assign_username_parameter['KODE_UNIK_USERNAME'] = $kode_unik_username;
		$function_AssignWifiidUsername = AssignWifiidUsername($assign_username_parameter);
		$function_AssignWifiidPassword = AssignWifiidPassword($assign_username_parameter);
		
	}
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Voucher telah berhasil di generate." ;
	
	/*
	$query_check = 
	"
	select
		count(b.ID) as total_row
	from master_voucher b
	where
		b.BRAND = '".addslashes($input_parameter['BRAND'])."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Merk (".$input_parameter['BRAND'].") telah digunakan. Silahkan mencoba kembali dengan merk yang lain.";
	} else {
	
		$query_add = 
		"
		insert into master_voucher
		(
		BRAND
		)
		values
		(
		'".addslashes($input_parameter['BRAND'])."'
		)
		";
		$result_add = $db->query($query_add);
	
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Merk telah berhasil ditambahkan." ;
		$function_result['NEW_ID'] = $db->insert_id;
	}
	*/
	
	return $function_result;
}

function GenerateMassVoucherByAgentID($input_parameter){
	global $db;
	
	$agent_id = $input_parameter['AGENT_ID'];
	$total_voucher = $input_parameter['TOTAL_VOUCHER'];
	
	$function_GetLastProductionBatch = GetLastProductionBatch();
	$nextbatch = $function_GetLastProductionBatch + 1;
	
	for( $i=0;$i<$total_voucher;$i++ ){
		
		$query_add = 
		"
		insert into
			master_voucher
		(
		BATCH_ID,
		IS_BOOKED,
		AGENT_ID,
		DATE_CREATED
		)
		values
		(
		'".$nextbatch."',
		'1',
		'".$agent_id."',
		'".date('Y-m-d H:i:s')."'
		)
		";
		$result_add = $db->query($query_add);
		$this_voucher_id = $db->insert_id;
		
		$assign_username_parameter['ID'] = $this_voucher_id;
		$assign_username_parameter['NEXT_BATCH'] = $nextbatch;
		$function_AssignWifiidUsername = AssignWifiidUsername($assign_username_parameter);
		$function_AssignWifiidPassword = AssignWifiidPassword($assign_username_parameter);
		
	}
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Voucher telah berhasil di generate." ;
	$function_result['PRODUCED_BATCH_ID'] = $assign_username_parameter['NEXT_BATCH'];
	
	return $function_result;
}

function UpdateMasterVoucherByID($input_parameter){
	global $db;
	
	$query_check = 
	"
	select
		count(b.ID) as total_row
	from master_voucher b
	where
		b.BRAND = '".addslashes($input_parameter['BRAND'])."'
		and b.ID != '".$input_parameter['ID']."'
	";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	$total_row = $row_check['total_row'];
	
	if( $total_row > 0 ){
		$function_result['RESULT'] = 0;
		$function_result['MESSAGE'] = "Merk (".$input_parameter['BRAND'].") telah digunakan. Silahkan mencoba kembali dengan merk yang lain.";
	} else {
	
		$query_update = 
		"
		update
			master_voucher b
		set
			b.BRAND = '".addslashes($input_parameter['BRAND'])."'
		where
			b.ID = '".$input_parameter['ID']."'
		";
		$result_update = $db->query($query_update);
	
		$function_result['RESULT'] = 1;
		$function_result['MESSAGE'] = "Data merk telah berhasil diperbaharui." ;
	}
	
	return $function_result;
}

function DeleteMasterVoucherByID($input_parameter){
	global $db;
	
	$query_delete = 
	"
	delete 
	from master_voucher
	where ID = '".$input_parameter['ID']."'
	";
	$result_delete = $db->query($query_delete);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Data merk telah berhasil dihapus.";
	
	return $function_result;
}

function GetMasterVoucherByID($input_parameter){
	global $db;
	
	$query_get = "select * from master_voucher where ID = '".$input_parameter['ID']."' ";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_master_voucher[] = stripslashes($row_get['BRAND']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['BRAND'] = $array_master_voucher;
	
	return $grand_array;

}

function GetAllMasterVoucher(){
	global $db;
	
	$query_get = "select * from master_voucher";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_batchid[] = stripslashes($row_get['BATCH_ID']);
		$array_username[] = stripslashes($row_get['USERNAME']);
		$array_password[] = stripslashes($row_get['PASSWORD']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_isbooked[] = stripslashes($row_get['IS_BOOKED']);
		$array_agentid[] = stripslashes($row_get['AGENT_ID']);
		$array_isbought[] = stripslashes($row_get['IS_BOUGHT']);
		$array_datecreated[] = stripslashes($row_get['DATE_CREATED']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['BATCH_ID'] = $array_batchid;
	$grand_array['USERNAME'] = $array_username;
	$grand_array['PASSWORD'] = $array_password;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['IS_BOOKED'] = $array_isbooked;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['IS_BOUGHT'] = $array_isbought;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	
	return $grand_array;
}

function GetMasterVoucherByBatchID($input_parameter){
	global $db;
	
	$query_get = "select * from master_voucher where batch_id = '".$input_parameter['BATCH_ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_batchid[] = stripslashes($row_get['BATCH_ID']);
		$array_username[] = stripslashes($row_get['USERNAME']);
		$array_password[] = stripslashes($row_get['PASSWORD']);
		$array_isactive[] = stripslashes($row_get['IS_ACTIVE']);
		$array_isbooked[] = stripslashes($row_get['IS_BOOKED']);
		$array_agentid[] = stripslashes($row_get['AGENT_ID']);
		$array_isbought[] = stripslashes($row_get['IS_BOUGHT']);
		$array_datecreated[] = stripslashes($row_get['DATE_CREATED']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['BATCH_ID'] = $array_batchid;
	$grand_array['USERNAME'] = $array_username;
	$grand_array['PASSWORD'] = $array_password;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['IS_BOOKED'] = $array_isbooked;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['IS_BOUGHT'] = $array_isbought;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	
	return $grand_array;
}

function EmptyMasterVoucher(){
	global $db;
	
	$query_empty = 
	"
	truncate master_voucher;
	";
	$result_empty = $db->query($query_empty);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Semua master voucher telah berhasil dihapus.";
	
	return $function_result;
}

function GetLastProductionBatch(){
	
	global $db;
	
	$query_get = "select max(BATCH_ID) as LAST_BATCH from master_voucher";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$last_batch = $row_get['LAST_BATCH'];
	
	return $last_batch;
	
}

function GetOverviewBatch(){
	
	global $db;
	
	$query_select = 
	"
	select
		count(ID) as TOTAL_VOUCHER,
		IS_ACTIVE,
		BATCH_ID,
		DATE_CREATED
	from master_voucher
	group by BATCH_ID
	order by BATCH_ID DESC
	";
	$result_select = $db->query($query_select);
	$num_select = $result_select->num_rows;
	
	for( $i=0;$i<$num_select;$i++ ){
		$row_select = $result_select->fetch_assoc();
		$array_totalvoucher[] = $row_select['TOTAL_VOUCHER'];
		$array_isactive[] = $row_select['IS_ACTIVE'];
		$array_batchid[] = $row_select['BATCH_ID'];
		$array_datecreated[] = $row_select['DATE_CREATED'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_select;
	$grand_array['TOTAL_VOUCHER'] = $array_totalvoucher;
	$grand_array['IS_ACTIVE'] = $array_isactive;
	$grand_array['BATCH_ID'] = $array_batchid;
	$grand_array['DATE_CREATED'] = $array_datecreated;
	
	return $grand_array;
	
}

function ActivateBatch($input_parameter){
	
	global $db;
	
	//UPDATE STATUS AKTIF MASTER VOUCHER (PERINTILAN)
	$query_update = 
	"
	update master_voucher 
	set 
		username = concat(username,'JPU@violet'),
		is_active = '1'
	where 
		BATCH_ID = '".$input_parameter['BATCH_ID']."'
	";
	$result_update = $db->query($query_update);

	//UPDATE STATUS AKTIF DEPOSIT (BONGGOL)
	$query_update = 
	"
	update voucher 
	set 
		is_active = '1', 
		QUANTITY_AVAILABLE = QUANTITY_ISSUED,
		DATE_EXPIRED = '".date('Y-m-d', strtotime('+1 years'))."'
	where 
		BATCH_ID = '".$input_parameter['BATCH_ID']."'
	";
	$result_update = $db->query($query_update);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Batch (".$input_parameter['BATCH_ID'].") telah berhasil diaktifasi.";
	
	return $function_result;
	
}











// USERNAME GENERATOR

function AssignWifiidUsername($input_parameter){
	
	global $db;
	
	for( $i=0;$i<2;$j++ ){
	
		$prefixusername = $input_parameter['NEXT_BATCH'].'JPU';
		$wifiid_username_randomized = GenerateWifiidUsername();
		$new_complete_wifiidusername = $prefixusername.$wifiid_username_randomized;
		$input_parameter_check['SUGGESTED_WIFIID_USERNAME'] = $new_complete_wifiidusername;	
		
		if( CheckDuplicateWifiidUsername($input_parameter_check) == 0 ){
			break;
		}
	}
	
	$query_update = "update master_voucher set USERNAME = '".$input_parameter_check['SUGGESTED_WIFIID_USERNAME']."' where ID = '".$input_parameter['ID']."'";
	$result = $db->query($query_update);
	
}

function GenerateWifiidUsername(){
	
	$str = 'ABCDEFGHJKMNPQRSTUVWXYZ';
	
	for( $i=0;$i<3;$i++ ){
		$agent_code .= $str[rand(0, strlen($str)-1)];
	}
	
	return $agent_code;
	
}

function CheckDuplicateWifiidUsername($input_parameter){
	
	global $db;
	
	$query_check = "select count(ID) as total_row from master_voucher where username = '".$input_parameter['SUGGESTED_WIFIID_USERNAME']."'";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	
	if( $row_check['total_row'] == 1 ){
		return 1;
	} else if( $row_check['total_row'] == 0 ) {
		return 0;
	}
	
}







// PASSWORD GENERATOR

function AssignWifiidPassword($input_parameter){
	
	global $db;
	
	for( $i=0;$i<2;$j++ ){
	
		$wifiid_password_randomized = GenerateWifiidPassword();
		$input_parameter_check['SUGGESTED_WIFIID_PASSWORD'] = $wifiid_password_randomized;
		
		if( CheckDuplicateWifiidPassword($input_parameter_check) == 0 ){
			break;
		}
		
	}
	
	$query_update = "update master_voucher set PASSWORD = '".$input_parameter_check['SUGGESTED_WIFIID_PASSWORD']."' where ID = '".$input_parameter['ID']."'";
	$result = $db->query($query_update);
	
}

function GenerateWifiidPassword(){
	
	$str = '23456789';
	
	for( $i=0;$i<8;$i++ ){
		$agent_code .= $str[rand(0, strlen($str)-1)];
	}
	
	return $agent_code;
	
}

function CheckDuplicateWifiidPassword($input_parameter){
	
	global $db;
	
	$query_check = "select count(ID) as total_row from master_voucher where password = '".$input_parameter['SUGGESTED_WIFIID_PASSWORD']."'";
	$result_check = $db->query($query_check);
	$row_check = $result_check->fetch_assoc();
	
	if( $row_check['total_row'] == 1 ){
		return 1;
	} else if( $row_check['total_row'] == 0 ) {
		return 0;
	}
	
}





?>