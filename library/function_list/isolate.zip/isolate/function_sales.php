<?php

/*==========================================

/*==========================================*/

function AddTransaction($input_parameter){
	global $db;
	
	$input_parameter['AGENT_ID'] = $input_parameter['AGENT_ID'];
	$function_GetEarliestAvailableVoucherID = GetEarliestAvailableVoucherID($input_parameter);
	$voucher_id = $function_GetEarliestAvailableVoucherID;
	
	$query_add = 
	"
	insert into transaction
	(
	AGENT_ID,
	VOUCHER_ID,
	DISTRIBUTION_METHOD,
	IS_VERIFIED,
	DATE_CREATED
	)
	values
	(
	'".addslashes($input_parameter['AGENT_ID'])."',
	'".addslashes($voucher_id)."',
	'".addslashes($input_parameter['DISTRIBUTION_METHOD'])."',
	'1',
	'".date('Y-m-d H:i:s')."'
	)
	";
	$result_add = $db->query($query_add);

	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Penjualan telah berhasil ditambahkan." ;
	$function_result['NEW_ID'] = $db->insert_id;
	
	if( $input_parameter['DISTRIBUTION_METHOD'] == 1 ){
		$query_update = "update transaction set email = '".$input_parameter['EMAIL']."' where ID = '".$function_result['NEW_ID']."'";
	} else if( $input_parameter['DISTRIBUTION_METHOD'] == 2 ){
		$query_update = "update transaction set sms = '".$input_parameter['SMS']."', email = '".$input_parameter['EMAIL']."' where ID = '".$function_result['NEW_ID']."'";
	}
	$result_update = $db->query($query_update);
	
	//KURANGI AVAILABLE QUANTITY
	$query_update = "update voucher set QUANTITY_AVAILABLE = (QUANTITY_AVAILABLE - 1) where ID = '".$voucher_id."'";
	$result_update = $db->query($query_update);
	
	//CARI VOUCHER YANG AVAILABLE
	$query_get_available = 
	"
	select * 
	from master_voucher 
	where 
		IS_ACTIVE = 1
		and IS_BOOKED = 1
		and AGENT_ID = '".addslashes($input_parameter['AGENT_ID'])."'
		and IS_BOUGHT = 0
	";
	$result_get_available = $db->query($query_get_available);
	$row_get_available = $result_get_available->fetch_assoc();
	$id_master_voucher_available = $row_get_available['ID'];
	$username_available = $row_get_available['USERNAME'];
	$password_available = $row_get_available['PASSWORD'];
	$function_result['USERNAME'] = $username_available;
	$function_result['PASSWORD'] = $password_available;
	
	//UBAH STATUS BOUGHT MASTER VOUCHER
	$query_void = "update master_voucher set IS_BOUGHT = 1 where ID = '".$id_master_voucher_available."'";
	$result_void = $db->query($query_void);
	
	//UPDATE MASTER VOUCHER ID DI TABLE TRANSACTION
	$query_update = "update transaction set master_voucher_id = '".$id_master_voucher_available."' where id = '".$function_result['NEW_ID']."'";
	$result_update = $db->query($query_update);
	
	//ADD COMISSION LOG
	$distribution_parameter['ID'] = $input_parameter['AGENT_ID'];
	$distribution_parameter['TRANSACTION_ID'] = $function_result['NEW_ID'];
	$function_DistributeComission = DistributeComission($distribution_parameter);
	
	return $function_result;
}

function GetAllTransaction(){
	
	global $db;
	
	$query_get = "select * from transaction";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentid[] = stripslashes($row_get['AGENT_ID']);
		$array_voucherid[] = stripslashes($row_get['VOUCHER_ID']);
		$array_mastervoucherid[] = stripslashes($row_get['MASTER_VOUCHER_ID']);
		$array_distributionmethod[] = stripslashes($row_get['DISTRIBUTION_METHOD']);
		$array_email[] = stripslashes($row_get['EMAIL']);
		$array_sms[] = stripslashes($row_get['SMS']);
		$array_isverified[] = stripslashes($row_get['IS_VERIFIED']);
		$array_datecreated[] = stripslashes($row_get['DATE_CREATED']);
		$array_dateverified[] = stripslashes($row_get['DATE_VERIFIED']);
		
		$query_get_userpass = "select * from master_voucher where id = '".$row_get['MASTER_VOUCHER_ID']."'";
		$result_get_userpass = $db->query($query_get_userpass);
		$row_get_userpass = $result_get_userpass->fetch_assoc();
		$array_wifiidusername[] = stripslashes($row_get_userpass['USERNAME']);
		$array_wifiidpassword[] = stripslashes($row_get_userpass['PASSWORD']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_ID'] =  $array_agentid;
	$grand_array['VOUCHER_ID'] =  $array_voucherid;
	$grand_array['MASTER_VOUCHER_ID'] = $array_mastervoucherid;
	$grand_array['DISTRIBUTION_METHOD'] =  $array_distributionmethod;
	$grand_array['EMAIL'] =  $array_email;
	$grand_array['SMS'] =  $array_sms;
	$grand_array['WIFIID_USERNAME'] = $array_wifiidusername;
	$grand_array['WIFIID_PASSWORD'] = $array_wifiidpassword;
	$grand_array['IS_VERIFIED'] = $array_isverified;
	$grand_array['DATE_CREATED'] =  $array_datecreated;
	$grand_array['DATE_VERIFIED'] =  $array_dateverified;
	
	return $grand_array;
}

function GetTransactionByID($input_parameter){
	
	global $db;
	
	$query_get = "select * from transaction where ID = '".$input_parameter['ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for($i=0;$i<$num_get;$i++){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_agentid[] = stripslashes($row_get['AGENT_ID']);
		$array_voucherid[] = stripslashes($row_get['VOUCHER_ID']);
		$array_mastervoucherid[] = stripslashes($row_get['MASTER_VOUCHER_ID']);
		$array_distributionmethod[] = stripslashes($row_get['DISTRIBUTION_METHOD']);
		$array_email[] = stripslashes($row_get['EMAIL']);
		$array_sms[] = stripslashes($row_get['SMS']);
		$array_isverified[] = stripslashes($row_get['IS_VERIFIED']);
		$array_datecreated[] = stripslashes($row_get['DATE_CREATED']);
		$array_dateverified[] = stripslashes($row_get['DATE_VERIFIED']);
		
		$query_get_userpass = "select * from master_voucher where id = '".$row_get['MASTER_VOUCHER_ID']."'";
		$result_get_userpass = $db->query($query_get_userpass);
		$row_get_userpass = $result_get_userpass->fetch_assoc();
		$array_wifiidusername[] = stripslashes($row_get_userpass['USERNAME']);
		$array_wifiidpassword[] = stripslashes($row_get_userpass['PASSWORD']);
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['ID'] = $array_id;
	$grand_array['AGENT_ID'] =  $array_agentid;
	$grand_array['VOUCHER_ID'] =  $array_voucherid;
	$grand_array['MASTER_VOUCHER_ID'] = $array_mastervoucherid;
	$grand_array['DISTRIBUTION_METHOD'] =  $array_distributionmethod;
	$grand_array['EMAIL'] =  $array_email;
	$grand_array['SMS'] =  $array_sms;
	$grand_array['WIFIID_USERNAME'] = $array_wifiidusername;
	$grand_array['WIFIID_PASSWORD'] = $array_wifiidpassword;
	$grand_array['IS_VERIFIED'] = $array_isverified;
	$grand_array['DATE_CREATED'] =  $array_datecreated;
	$grand_array['DATE_VERIFIED'] =  $array_dateverified;
	
	return $grand_array;
}

function VerifyTransaction($input_parameter){
	
	global $db;
	
	$query_update = 
	"
	update transaction 
		set IS_VERIFIED = '".$input_parameter['IS_VERIFIED']."'
		,WIFIID_USERNAME = '".$input_parameter['WIFIID_USERNAME']."'
		,WIFIID_PASSWORD = '".$input_parameter['WIFIID_PASSWORD']."'
		,DATE_VERIFIED = '".date('Y-m-d H:i:s')."'
	where 
		ID = '".$input_parameter['ID']."'
	";
	//echo $query_update;exit;
	$result_update = $db->query($query_update);
	
	$function_result['RESULT'] = 1;
	$function_result['MESSAGE'] = "Transaksi telah berhasil diverifikasi.";
	
	$transaction_input_parameter['ID'] = $input_parameter['ID'];
	$function_GetTransactionByID = GetTransactionByID($transaction_input_parameter);
	$seller_agent_id = $function_GetTransactionByID['AGENT_ID'][0];
	
	$distribution_parameter['ID'] = $seller_agent_id;
	$distribution_parameter['TRANSACTION_ID'] = $input_parameter['ID'];
	$function_DistributeComission = DistributeComission($distribution_parameter);
	
	return $function_result;
	
}

function DistributeComission($input_parameter){
	
	global $db;
	
	for($i=0;$i<2;$j++){
		
		if( $input_parameter['ID'] == 769 ){
			break;
		}
		
		$current_agent_parameter['ID'] = $input_parameter['ID'];
		$function_GetAgentByID = GetAgentByID($current_agent_parameter);
		$referal_id = $function_GetAgentByID['REFERAL_ID'][0];
		//echo $referal_id;exit;
		
		//GET COMISSION VALUE
		$referal_parameter['ID'] = $referal_id;
		$function_GetCurrentComissionbyAgentID = GetCurrentComissionbyAgentID($referal_parameter);
		$referal_comission_value = $function_GetCurrentComissionbyAgentID['COMISSION'];
		
		$query_add = 
		"
		insert into
			comission_log
		(
		TRANSACTION_ID,
		AGENT_ID,
		COMISSION,
		DATE_CREATED
		)
		values
		(
		'".$input_parameter['TRANSACTION_ID']."',
		'".$referal_parameter['ID']."',
		'".$referal_comission_value."',
		'".date('Y-m-d H:i:s')."'
		)
		";
		//echo $query_add.'<br/>';
		$result_add = $db->query($query_add);
		
		$input_parameter['ID'] = $referal_parameter['ID'];
		
	}
	
}

function GetTotalSalesTodayByAgentID($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		count(ID) as num_of_sales 
	from 
		transaction 
	where 
		AGENT_ID = '".$input_parameter['ID']."' 
		and DATE(DATE_VERIFIED) = CURDATE()
	";
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$num_of_sales = $row_get['num_of_sales'];
	
	return $num_of_sales;
	
}

function GetTotalSalesThisMonthByAgentID($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		count(ID) as num_of_sales 
	from 
		transaction 
	where 
		AGENT_ID = '".$input_parameter['ID']."' 
		and MONTH(DATE_VERIFIED) = MONTH(CURRENT_DATE())
	";
	//echo $query_get;exit;
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$num_of_sales = $row_get['num_of_sales'];
	
	return $num_of_sales;
	
}

function GetTotalSalesThisYearByAgentID($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		count(ID) as num_of_sales 
	from 
		transaction 
	where 
		AGENT_ID = '".$input_parameter['ID']."' 
		and YEAR(DATE_VERIFIED) = YEAR(CURRENT_DATE())
	";
	//echo $query_get;exit;
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$num_of_sales = $row_get['num_of_sales'];
	
	return $num_of_sales;
	
}

function GetTotalSalesByAgentID($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		count(ID) as num_of_sales 
	from 
		transaction 
	where 
		AGENT_ID = '".$input_parameter['ID']."' 
		and DATE_VERIFIED != '0000-00-00 00:00:00'
	";
	//echo $query_get;exit;
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$num_of_sales = $row_get['num_of_sales'];
	
	return $num_of_sales;
	
}

function GetTotalSalesGivenMonthThisYearByAgentID($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		count(ID) as num_of_sales 
	from 
		transaction 
	where 
		AGENT_ID = '".$input_parameter['ID']."' 
		and MONTH(DATE_CREATED) = '".$input_parameter['MONTH']."'
		and YEAR(DATE_CREATED) = YEAR(CURRENT_DATE())
	";
	//echo $query_get;exit;
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$num_of_sales = $row_get['num_of_sales'];
	
	return $num_of_sales;
	
}

function GetTotalSalesGivenMonthThisYear($input_parameter){
	
	global $db;
	
	$query_get = 
	"
	select 
		count(ID) as num_of_sales 
	from 
		transaction 
	where 
		MONTH(DATE_CREATED) = '".$input_parameter['MONTH']."'
		and YEAR(DATE_CREATED) = YEAR(CURRENT_DATE())
	";
	//echo $query_get;exit;
	$result_get = $db->query($query_get);
	$row_get = $result_get->fetch_assoc();
	$num_of_sales = $row_get['num_of_sales'];
	
	return $num_of_sales;
	
}




// COMISSION CENTRAL

function GetAllComission(){
	
	global $db;
	
	$query_get = "select * from comission_log";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}

function GetAllComissionToday(){
	
	global $db;
	
	$query_get = "select * from comission_log where DATE(date_created) = CURDATE()";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}

function GetAllComissionThisMonth(){
	
	global $db;
	
	$query_get = "select * from comission_log where MONTH(date_created) = month(CURRENT_DATE())";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}

function GetAllComissionThisYear(){
	
	global $db;
	
	$query_get = "select * from comission_log where YEAR(date_created) = YEAR(CURRENT_DATE())";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}




// COMISSION AGEN

function GetAllComissionByAgentID($input_parameter){
	
	global $db;
	
	$query_get = "select * from comission_log where AGENT_ID = '".$input_parameter['AGENT_ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}

function GetAllComissionTodayByAgentID($input_parameter){
	
	global $db;
	
	$query_get = "select * from comission_log where DATE(date_created) = CURDATE() and AGENT_ID = '".$input_parameter['AGENT_ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}

function GetAllComissionThisMonthByAgentID($input_parameter){
	
	global $db;
	
	$query_get = "select * from comission_log where MONTH(date_created) = month(CURRENT_DATE()) and AGENT_ID = '".$input_parameter['AGENT_ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}

function GetAllComissionThisYearByAgentID($input_parameter){
	
	global $db;
	
	$query_get = "select * from comission_log where YEAR(date_created) = YEAR(CURRENT_DATE()) and AGENT_ID = '".$input_parameter['AGENT_ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}

function GetComissionDetailByID($input_parameter){
	
	global $db;
	
	$query_get = "select * from comission_log where ID = '".$input_parameter['AGENT_ID']."'";
	$result_get = $db->query($query_get);
	$num_get = $result_get->num_rows;
	
	for( $i=0;$i<$num_get;$i++ ){
		$row_get = $result_get->fetch_assoc();
		$array_id[] = $row_get['ID'];
		$array_transactionid[] = $row_get['TRANSACTION_ID'];
		$array_agentid[] = $row_get['AGENT_ID'];
		$array_comission[] = $row_get['COMISSION'];
		$array_datecreated[] = $row_get['DATE_CREATED'];
		$total_comission += $row_get['COMISSION'];
	}
	
	$grand_array['TOTAL_ROW'] = $num_get;
	$grand_array['TOTAL_COMISSION'] = $total_comission;
	$grand_array['ID'] = $array_id;
	$grand_array['TRANSACTION_ID'] = $array_transactionid;
	$grand_array['AGENT_ID'] = $array_agentid;
	$grand_array['COMISSION'] = $array_comission;
	$grand_array['DATE_CREATED'] = $array_datecreated;

	return $grand_array;
	
}



?>